package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.CompareArrows
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalDrawerSheet
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.NavigationDrawerItem
import androidx.compose.material3.NavigationDrawerItemDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.screens.AboutScreen
import com.example.ui.screens.AiAssistantChatScreen
import com.example.ui.screens.AiReportScreen
import com.example.ui.screens.DashboardScreen
import com.example.ui.screens.EngineHealthScreen
import com.example.ui.screens.FindingDetailScreen
import com.example.ui.screens.HistoryScreen
import com.example.ui.screens.NewScanScreen
import com.example.ui.screens.OwaspCoverageScreen
import com.example.ui.screens.ResultsScreen
import com.example.ui.screens.ScanComparisonScreen
import com.example.ui.screens.ScanProgressScreen
import com.example.ui.screens.SelfTestLabScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.screens.SplashScreen
import com.example.ui.screens.StaticCodeAuditScreen
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.CyberEmerald
import com.example.ui.theme.DarkVoid
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.viewmodel.AppScreen
import com.example.ui.viewmodel.AuditorViewModel
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {

    private val viewModel: AuditorViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val isEnglish by viewModel.isEnglish.collectAsState()
            val layoutDirection = if (isEnglish) LayoutDirection.Ltr else LayoutDirection.Rtl

            CompositionLocalProvider(LocalLayoutDirection provides layoutDirection) {
                MyApplicationTheme(darkTheme = true) {
                    MainAppScaffold(viewModel = viewModel)
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainAppScaffold(viewModel: AuditorViewModel) {
    val currentScreen by viewModel.currentScreen.collectAsState()
    val isEnglish by viewModel.isEnglish.collectAsState()
    val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)
    val coroutineScope = rememberCoroutineScope()

    // 1. Splash Screen Mode: Full Screen Without Shell
    if (currentScreen == AppScreen.SPLASH) {
        SplashScreen(
            onContinue = { viewModel.dismissSplash() },
            isEnglish = isEnglish
        )
        return
    }

    // 2. Predictive Back Navigation
    BackHandler(enabled = true) {
        if (drawerState.isOpen) {
            coroutineScope.launch { drawerState.close() }
        } else if (currentScreen != AppScreen.DASHBOARD) {
            viewModel.navigateTo(AppScreen.DASHBOARD)
        }
    }

    ModalNavigationDrawer(
        drawerState = drawerState,
        modifier = Modifier.testTag("app_navigation_drawer"),
        drawerContent = {
            ModalDrawerSheet(
                drawerContainerColor = MaterialTheme.colorScheme.surface,
                drawerContentColor = MaterialTheme.colorScheme.onSurface,
                modifier = Modifier
                    .width(310.dp)
                    .fillMaxSize()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .verticalScroll(rememberScrollState())
                        .padding(horizontal = 16.dp, vertical = 20.dp)
                ) {
                    // Drawer Header
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(bottom = 16.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(42.dp)
                                .clip(RoundedCornerShape(10.dp))
                                .background(MaterialTheme.colorScheme.primaryContainer),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Shield,
                                contentDescription = null,
                                tint = CyberCyan,
                                modifier = Modifier.size(24.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = if (isEnglish) "AI Security Auditor" else "المدقق الذكي للأمان",
                                fontWeight = FontWeight.Bold,
                                fontSize = 15.sp,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = if (isEnglish) "17 Native Modules • ARM64" else "١٧ شاشة ووحدة أمنية أصلية",
                                fontSize = 11.sp,
                                color = CyberEmerald
                            )
                        }
                    }

                    HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.5f))
                    Spacer(modifier = Modifier.height(10.dp))

                    // Group 1: Core Auditing & Scans
                    DrawerCategoryHeader(if (isEnglish) "CORE AUDITING & SCANS" else "الفحص والتقييم الأمني")
                    DrawerNavOption(AppScreen.DASHBOARD, Icons.Default.Shield, currentScreen, isEnglish) {
                        viewModel.navigateTo(AppScreen.DASHBOARD)
                        coroutineScope.launch { drawerState.close() }
                    }
                    DrawerNavOption(AppScreen.NEW_SCAN, Icons.Default.PlayArrow, currentScreen, isEnglish) {
                        viewModel.navigateTo(AppScreen.NEW_SCAN)
                        coroutineScope.launch { drawerState.close() }
                    }
                    DrawerNavOption(AppScreen.SCAN_PROGRESS, Icons.Default.Security, currentScreen, isEnglish) {
                        viewModel.navigateTo(AppScreen.SCAN_PROGRESS)
                        coroutineScope.launch { drawerState.close() }
                    }
                    DrawerNavOption(AppScreen.FINDINGS, Icons.Default.Security, currentScreen, isEnglish) {
                        viewModel.navigateTo(AppScreen.FINDINGS)
                        coroutineScope.launch { drawerState.close() }
                    }
                    DrawerNavOption(AppScreen.VIEW_FIX, Icons.Default.Security, currentScreen, isEnglish) {
                        viewModel.navigateTo(AppScreen.VIEW_FIX)
                        coroutineScope.launch { drawerState.close() }
                    }
                    DrawerNavOption(AppScreen.SCAN_COMPARISON, Icons.Default.CompareArrows, currentScreen, isEnglish) {
                        viewModel.navigateTo(AppScreen.SCAN_COMPARISON)
                        coroutineScope.launch { drawerState.close() }
                    }
                    DrawerNavOption(AppScreen.SCAN_HISTORY, Icons.Default.History, currentScreen, isEnglish) {
                        viewModel.navigateTo(AppScreen.SCAN_HISTORY)
                        coroutineScope.launch { drawerState.close() }
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                    HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.5f))
                    Spacer(modifier = Modifier.height(8.dp))

                    // Group 2: Built-in Analysis Tools
                    DrawerCategoryHeader(if (isEnglish) "DEFENSIVE TOOLS SUITE" else "أدوات التحليل المدمجة")
                    DrawerNavOption(AppScreen.STATIC_CODE, Icons.Default.Security, currentScreen, isEnglish) {
                        viewModel.navigateTo(AppScreen.STATIC_CODE)
                        coroutineScope.launch { drawerState.close() }
                    }
                    DrawerNavOption(AppScreen.SELF_TEST_LAB, Icons.Default.CheckCircle, currentScreen, isEnglish) {
                        viewModel.navigateTo(AppScreen.SELF_TEST_LAB)
                        coroutineScope.launch { drawerState.close() }
                    }
                    DrawerNavOption(AppScreen.OWASP_COVERAGE, Icons.Default.Shield, currentScreen, isEnglish) {
                        viewModel.navigateTo(AppScreen.OWASP_COVERAGE)
                        coroutineScope.launch { drawerState.close() }
                    }
                    DrawerNavOption(AppScreen.ENGINE_HEALTH, Icons.Default.Security, currentScreen, isEnglish) {
                        viewModel.navigateTo(AppScreen.ENGINE_HEALTH)
                        coroutineScope.launch { drawerState.close() }
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                    HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.5f))
                    Spacer(modifier = Modifier.height(8.dp))

                    // Group 3: Intelligence & Reporting
                    DrawerCategoryHeader(if (isEnglish) "INTELLIGENCE & REPORTS" else "المستشار والتقارير")
                    DrawerNavOption(AppScreen.AI_ASSISTANT, Icons.Default.AutoAwesome, currentScreen, isEnglish) {
                        viewModel.navigateTo(AppScreen.AI_ASSISTANT)
                        coroutineScope.launch { drawerState.close() }
                    }
                    DrawerNavOption(AppScreen.REPORTS, Icons.Default.Description, currentScreen, isEnglish) {
                        viewModel.navigateTo(AppScreen.REPORTS)
                        coroutineScope.launch { drawerState.close() }
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                    HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.5f))
                    Spacer(modifier = Modifier.height(8.dp))

                    // Group 4: System & Specs
                    DrawerCategoryHeader(if (isEnglish) "SYSTEM & HARDWARE" else "النظام والمواصفات")
                    DrawerNavOption(AppScreen.SETTINGS, Icons.Default.Settings, currentScreen, isEnglish) {
                        viewModel.navigateTo(AppScreen.SETTINGS)
                        coroutineScope.launch { drawerState.close() }
                    }
                    DrawerNavOption(AppScreen.ABOUT, Icons.Default.Info, currentScreen, isEnglish) {
                        viewModel.navigateTo(AppScreen.ABOUT)
                        coroutineScope.launch { drawerState.close() }
                    }

                    Spacer(modifier = Modifier.height(20.dp))
                }
            }
        }
    ) {
        Scaffold(
            modifier = Modifier.fillMaxSize(),
            containerColor = MaterialTheme.colorScheme.background,
            topBar = {
                TopAppBar(
                    title = {
                        Column {
                            Text(
                                text = if (isEnglish) currentScreen.labelEn else currentScreen.labelAr,
                                fontWeight = FontWeight.Bold,
                                fontSize = 16.sp,
                                maxLines = 1
                            )
                            Text(
                                text = if (isEnglish) "Defensive Security Auditor" else "المدقق الأمني الدفاعي",
                                fontSize = 10.sp,
                                color = CyberCyan
                            )
                        }
                    },
                    navigationIcon = {
                        if (currentScreen != AppScreen.DASHBOARD) {
                            IconButton(
                                onClick = { viewModel.navigateTo(AppScreen.DASHBOARD) },
                                modifier = Modifier.testTag("top_back_button")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.ArrowBack,
                                    contentDescription = "Back to Dashboard",
                                    tint = CyberCyan
                                )
                            }
                        } else {
                            IconButton(
                                onClick = { coroutineScope.launch { drawerState.open() } },
                                modifier = Modifier.testTag("top_menu_button")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Menu,
                                    contentDescription = "Menu",
                                    tint = CyberCyan
                                )
                            }
                        }
                    },
                    actions = {
                        // Quick switch language button
                        OutlinedButton(
                            onClick = { viewModel.toggleLanguage() },
                            shape = RoundedCornerShape(16.dp),
                            modifier = Modifier
                                .height(32.dp)
                                .testTag("top_lang_toggle")
                        ) {
                            Text(
                                text = if (isEnglish) "عربي" else "EN",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = CyberCyan
                            )
                        }
                        Spacer(modifier = Modifier.width(4.dp))
                        IconButton(
                            onClick = { coroutineScope.launch { drawerState.open() } },
                            modifier = Modifier.testTag("drawer_open_action")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Menu,
                                contentDescription = "All Screens",
                                tint = MaterialTheme.colorScheme.onSurface
                            )
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = MaterialTheme.colorScheme.surface,
                        titleContentColor = MaterialTheme.colorScheme.onSurface
                    )
                )
            },
            bottomBar = {
                NavigationBar(
                    containerColor = MaterialTheme.colorScheme.surface,
                    contentColor = MaterialTheme.colorScheme.onSurface,
                    modifier = Modifier.testTag("main_bottom_nav")
                ) {
                    val navItems = listOf(
                        AppScreen.DASHBOARD to Icons.Default.Shield,
                        AppScreen.NEW_SCAN to Icons.Default.PlayArrow,
                        AppScreen.FINDINGS to Icons.Default.Security,
                        AppScreen.AI_ASSISTANT to Icons.Default.AutoAwesome,
                        AppScreen.REPORTS to Icons.Default.Description
                    )

                    navItems.forEach { (screen, icon) ->
                        val isSelected = currentScreen == screen
                        NavigationBarItem(
                            selected = isSelected,
                            onClick = { viewModel.navigateTo(screen) },
                            icon = {
                                Icon(
                                    imageVector = icon,
                                    contentDescription = if (isEnglish) screen.labelEn else screen.labelAr
                                )
                            },
                            label = {
                                Text(
                                    text = if (isEnglish) screen.labelEn else screen.labelAr,
                                    fontSize = 10.sp,
                                    maxLines = 1
                                )
                            },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = Color.Black,
                                selectedTextColor = CyberCyan,
                                indicatorColor = CyberCyan,
                                unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
                                unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant
                            ),
                            modifier = Modifier.testTag("bottom_tab_${screen.name.lowercase()}")
                        )
                    }
                }
            }
        ) { innerPadding ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                when (currentScreen) {
                    AppScreen.SPLASH -> SplashScreen(onContinue = { viewModel.dismissSplash() }, isEnglish = isEnglish)
                    AppScreen.DASHBOARD -> DashboardScreen(viewModel = viewModel)
                    AppScreen.NEW_SCAN -> NewScanScreen(viewModel = viewModel)
                    AppScreen.SCAN_PROGRESS -> ScanProgressScreen(viewModel = viewModel)
                    AppScreen.FINDINGS -> ResultsScreen(viewModel = viewModel)
                    AppScreen.FINDING_DETAILS, AppScreen.VIEW_FIX -> FindingDetailScreen(viewModel = viewModel)
                    AppScreen.ENGINE_HEALTH -> EngineHealthScreen(isEnglish = isEnglish)
                    AppScreen.SCAN_HISTORY -> HistoryScreen(viewModel = viewModel)
                    AppScreen.SCAN_COMPARISON -> ScanComparisonScreen(viewModel = viewModel)
                    AppScreen.STATIC_CODE -> StaticCodeAuditScreen(isEnglish = isEnglish)
                    AppScreen.SELF_TEST_LAB -> SelfTestLabScreen(isEnglish = isEnglish)
                    AppScreen.OWASP_COVERAGE -> OwaspCoverageScreen(isEnglish = isEnglish)
                    AppScreen.REPORTS -> AiReportScreen(viewModel = viewModel)
                    AppScreen.AI_ASSISTANT -> AiAssistantChatScreen(viewModel = viewModel)
                    AppScreen.SETTINGS -> SettingsScreen(viewModel = viewModel)
                    AppScreen.ABOUT -> AboutScreen(isEnglish = isEnglish)
                }
            }
        }
    }
}

@Composable
private fun DrawerCategoryHeader(title: String) {
    Text(
        text = title,
        fontSize = 10.sp,
        fontWeight = FontWeight.Bold,
        color = CyberCyan,
        letterSpacing = 1.sp,
        modifier = Modifier.padding(vertical = 6.dp, horizontal = 4.dp)
    )
}

@Composable
private fun DrawerNavOption(
    screen: AppScreen,
    icon: ImageVector,
    currentScreen: AppScreen,
    isEnglish: Boolean,
    onClick: () -> Unit
) {
    val isSelected = currentScreen == screen
    NavigationDrawerItem(
        label = {
            Text(
                text = if (isEnglish) screen.labelEn else screen.labelAr,
                fontSize = 13.sp,
                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
            )
        },
        selected = isSelected,
        onClick = onClick,
        icon = {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = if (isSelected) Color.Black else CyberCyan,
                modifier = Modifier.size(18.dp)
            )
        },
        colors = NavigationDrawerItemDefaults.colors(
            selectedContainerColor = CyberCyan,
            selectedTextColor = Color.Black,
            unselectedTextColor = MaterialTheme.colorScheme.onSurface
        ),
        shape = RoundedCornerShape(8.dp),
        modifier = Modifier
            .padding(vertical = 2.dp)
            .testTag("drawer_item_${screen.name.lowercase()}")
    )
}
