package com.example.model

enum class Severity(val labelEn: String, val labelAr: String, val weight: Int) {
    CRITICAL("Critical", "حرجة", 25),
    HIGH("High", "مرتفعة", 15),
    MEDIUM("Medium", "متوسطة", 8),
    LOW("Low", "منخفضة", 3),
    INFO("Informational", "معلوماتية", 0)
}

enum class FindingClassification(val labelEn: String, val labelAr: String) {
    CONFIRMED_MISCONFIGURATION("Confirmed Misconfiguration", "خطأ إعداد مؤكد"),
    POTENTIAL_VULNERABILITY("Potential Vulnerability", "ثغرة أمنية محتملة"),
    CONFIRMED_VULNERABILITY("Confirmed Vulnerability", "ثغرة أمنية مؤكدة"),
    INFORMATIONAL("Informational", "معلومات إرشادية")
}

enum class Confidence(val labelEn: String, val labelAr: String) {
    CONFIRMED("Confirmed", "مؤكدة"),
    PROBABLE("Probable", "محتملة"),
    NEEDS_MANUAL_VERIFICATION("Needs Manual Check", "تحتاج تحققاً يدوياً")
}

enum class Category(val labelEn: String, val labelAr: String) {
    TLS_SSL("TLS / SSL Configuration", "إعدادات تشفير TLS وSSL"),
    SECURITY_HEADERS("HTTP Security Headers", "الترويسات الأمنية HTTP"),
    COOKIES("Cookie Security", "أمان ملفات تعريف الارتباط"),
    CORS("CORS & Origin Policies", "سياسات مشاركة الموارد CORS"),
    DNS_EMAIL("DNS & Email Security (SPF/DMARC)", "أمان DNS والبريد (SPF وDMARC)"),
    INFO_DISCLOSURE("Information Disclosure", "كشف معلومات الخادم والتقنيات"),
    STATIC_CODE("Static Source Code Review", "فحص الكود المصدري الثابت"),
    ARCHITECTURE("Architecture & Scope", "البنية ونطاق الاتصال")
}

enum class VisualDiagramType {
    TLS_HANDSHAKE,
    SECURITY_HEADERS,
    CSP_WHITELIST,
    COOKIE_FLAGS,
    CLICKJACKING,
    SPF_DMARC,
    CORS_MATRIX,
    INFO_DISCLOSURE,
    DNS_SECURITY,
    API_SURFACE,
    SECURITY_SCORE
}

data class SecurityFinding(
    val id: String,
    val title: String,
    val titleAr: String,
    val category: Category,
    val severity: Severity,
    val classification: FindingClassification = FindingClassification.CONFIRMED_MISCONFIGURATION,
    val confidence: Confidence = Confidence.CONFIRMED,
    val cvssScore: Double?,
    val cvssVector: String?,
    val owaspCategory: String,
    val cweId: String,
    val affectedComponent: String,
    val evidence: String,
    val explanationAr: String,
    val explanationEn: String,
    val impactAr: String,
    val impactEn: String,
    val remediationStepsAr: List<String>,
    val remediationStepsEn: List<String>,
    val configSnippet: String,
    val verificationCommand: String,
    val references: List<String>,
    val visualDiagram: VisualDiagramType? = null
)

data class AuditSummary(
    val id: String,
    val targetUrl: String,
    val scannedHost: String,
    val timestamp: Long,
    val durationMs: Long,
    val overallGrade: String,
    val score: Int,
    val isDemoScan: Boolean,
    val findings: List<SecurityFinding>,
    val executiveSummaryAr: String,
    val executiveSummaryEn: String,
    val technicalSummaryAr: String,
    val technicalSummaryEn: String,
    val tlsVersion: String,
    val tlsCipher: String,
    val certDaysRemaining: Int,
    val certIssuer: String,
    val scannedHeadersCount: Int,
    val dnsRecordsSummary: String = "",
    val testsRun: List<String>,
    val testsSkipped: List<String>,
    val actualRequestsCount: Int = 4,
    val engineErrors: List<String> = emptyList()
) {
    val criticalCount: Int get() = findings.count { it.severity == Severity.CRITICAL }
    val highCount: Int get() = findings.count { it.severity == Severity.HIGH }
    val mediumCount: Int get() = findings.count { it.severity == Severity.MEDIUM }
    val lowCount: Int get() = findings.count { it.severity == Severity.LOW }
    val infoCount: Int get() = findings.count { it.severity == Severity.INFO }
}

sealed class ScanState {
    object Idle : ScanState()
    data class Scanning(val step: String, val stepAr: String, val progress: Float, val currentLog: String = "") : ScanState()
    data class Success(val summary: AuditSummary) : ScanState()
    data class Error(val messageAr: String, val messageEn: String, val isSsrfBlocked: Boolean = false) : ScanState()
}

enum class TargetScope(val labelEn: String, val labelAr: String) {
    STRICT_HOST("Strict Hostname Only", "النطاق المحدد فقط (صارم)"),
    SAME_DOMAIN_SUBDOMAINS("Host & Subdomains", "النطاق والنطاقات الفرعية")
}

data class StaticCodeFinding(
    val id: String,
    val fileName: String,
    val lineNumber: Int,
    val ruleName: String,
    val ruleNameAr: String,
    val severity: Severity,
    val cweId: String,
    val codeSnippet: String,
    val explanationAr: String,
    val remediationAr: String
)

data class EngineStatus(
    val id: String,
    val name: String,
    val nameAr: String,
    val version: String,
    val isNativeAndroid: Boolean,
    val status: EngineState,
    val statusDescriptionAr: String,
    val statusDescriptionEn: String,
    val testsCount: Int
)

enum class EngineState(val labelEn: String, val labelAr: String) {
    READY("Ready", "جاهز للتشغيل"),
    RUNNING("Running", "قيد الفحص"),
    COMPLETED("Completed", "مكتمل"),
    EXTERNAL_REQUIRED("External Daemon Required", "يتطلب خادم خارجي"),
    NOT_AVAILABLE("Not Available on Android", "غير متاح على أندرويد"),
    FAILED("Failed", "فشل الاتصال")
}

data class SelfTestResult(
    val testId: String,
    val title: String,
    val titleAr: String,
    val category: String,
    val expected: String,
    val actual: String,
    val passed: Boolean,
    val detail: String
)

data class OwaspTop10Coverage(
    val code: String,
    val titleEn: String,
    val titleAr: String,
    val supportedChecks: List<String>,
    val executedChecksCount: Int,
    val skippedChecksCount: Int,
    val scopeLimitationsAr: String
)

data class AssistantMessage(
    val id: String,
    val isUser: Boolean,
    val text: String,
    val timestamp: Long = System.currentTimeMillis()
)
