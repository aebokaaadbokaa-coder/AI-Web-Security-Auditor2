package com.example.security

import com.example.model.Category
import com.example.model.Confidence
import com.example.model.FindingClassification
import com.example.model.SecurityFinding
import com.example.model.Severity
import com.example.model.VisualDiagramType
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.net.InetAddress
import java.util.concurrent.TimeUnit

object DnsSecurityAnalyzer {

    private val httpClient = OkHttpClient.Builder()
        .connectTimeout(5, TimeUnit.SECONDS)
        .readTimeout(5, TimeUnit.SECONDS)
        .build()

    data class DnsResult(
        val ipAddresses: List<String>,
        val spfRecord: String?,
        val dmarcRecord: String?,
        val findings: List<SecurityFinding>,
        val summaryText: String
    )

    suspend fun analyzeDns(host: String): DnsResult = withContext(Dispatchers.IO) {
        val findings = mutableListOf<SecurityFinding>()
        val ipList = mutableListOf<String>()
        var spfRecord: String? = null
        var dmarcRecord: String? = null

        // 1. Resolve host IP addresses via system DNS
        try {
            val addresses = InetAddress.getAllByName(host)
            for (addr in addresses) {
                ipList.add(addr.hostAddress ?: "")
            }
        } catch (_: Exception) {}

        // 2. Query TXT records for SPF and DMARC via public DoH (Cloudflare DNS over HTTPS)
        try {
            val dohTxtUrl = "https://cloudflare-dns.com/dns-query?name=$host&type=TXT"
            val request = Request.Builder()
                .url(dohTxtUrl)
                .header("Accept", "application/dns-json")
                .build()

            val response = httpClient.newCall(request).execute()
            if (response.isSuccessful) {
                val jsonStr = response.body?.string() ?: ""
                val json = JSONObject(jsonStr)
                val answers = json.optJSONArray("Answer")
                if (answers != null) {
                    for (i in 0 until answers.length()) {
                        val answer = answers.getJSONObject(i)
                        val data = answer.optString("data", "").replace("\"", "")
                        if (data.startsWith("v=spf1")) {
                            spfRecord = data
                        }
                    }
                }
            }
        } catch (_: Exception) {}

        // 3. Query DMARC TXT record (_dmarc.host)
        try {
            val dohDmarcUrl = "https://cloudflare-dns.com/dns-query?name=_dmarc.$host&type=TXT"
            val request = Request.Builder()
                .url(dohDmarcUrl)
                .header("Accept", "application/dns-json")
                .build()

            val response = httpClient.newCall(request).execute()
            if (response.isSuccessful) {
                val jsonStr = response.body?.string() ?: ""
                val json = JSONObject(jsonStr)
                val answers = json.optJSONArray("Answer")
                if (answers != null) {
                    for (i in 0 until answers.length()) {
                        val answer = answers.getJSONObject(i)
                        val data = answer.optString("data", "").replace("\"", "")
                        if (data.contains("v=DMARC1")) {
                            dmarcRecord = data
                        }
                    }
                }
            }
        } catch (_: Exception) {}

        // 4. Analyze SPF finding
        if (spfRecord == null) {
            findings.add(
                SecurityFinding(
                    id = "DNS-SPF-MISSING",
                    title = "Missing SPF (Sender Policy Framework) Record",
                    titleAr = "غياب سجل SPF لحماية البريد من الانتحال والتزوير",
                    category = Category.DNS_EMAIL,
                    severity = Severity.MEDIUM,
                    classification = FindingClassification.CONFIRMED_MISCONFIGURATION,
                    confidence = Confidence.CONFIRMED,
                    cvssScore = 5.3,
                    cvssVector = "CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:N/I:L/A:N",
                    owaspCategory = "A05:2021-Security Misconfiguration",
                    cweId = "CWE-345",
                    affectedComponent = "DNS TXT: $host",
                    evidence = "No TXT record starting with 'v=spf1' returned by DNS resolver.",
                    explanationAr = "سجل SPF يحدد خوادم البريد المخولة بإرسال رسائل نيابة عن نطاقك. غيابه يسمح للمهاجمين بإرسال رسائل تصيد احتيالي (Phishing) تنتحل اسم نطاقك.",
                    explanationEn = "Without SPF, attackers can forge email headers and send phishing emails appearing directly from your domain.",
                    impactAr = "انتحال هوية الموقع والبريد الإلكتروني للعملاء والموظفين وتشويه السمعة الرقمية.",
                    impactEn = "Domain spoofing, brand reputation damage, and successful spear-phishing campaigns.",
                    remediationStepsAr = listOf(
                        "أضف سجل TXT في لوحة تحكم DNS للنطاق يحتوي على خوادم البريد المعتمدة.",
                        "مثال لسجل صارم: 'v=spf1 include:_spf.google.com ~all' أو '-all'."
                    ),
                    remediationStepsEn = listOf(
                        "Add a TXT record for $host specifying authorized mail exchangers.",
                        "Enforce strict policy with ~all or -all."
                    ),
                    configSnippet = "$host. IN TXT \"v=spf1 include:_spf.example.com -all\"",
                    verificationCommand = "dig +short TXT $host",
                    references = listOf("https://tools.ietf.org/html/rfc7208"),
                    visualDiagram = VisualDiagramType.SPF_DMARC
                )
            )
        } else if (spfRecord.contains("+all")) {
            findings.add(
                SecurityFinding(
                    id = "DNS-SPF-PERMISSIVE",
                    title = "Insecure SPF Record Using Permissive '+all' Mechanism",
                    titleAr = "سجل SPF غير آمن يسمح لأي خادم في العالم بالإرسال (+all)",
                    category = Category.DNS_EMAIL,
                    severity = Severity.HIGH,
                    classification = FindingClassification.CONFIRMED_MISCONFIGURATION,
                    confidence = Confidence.CONFIRMED,
                    cvssScore = 6.5,
                    cvssVector = "CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:N/I:H/A:N",
                    owaspCategory = "A05:2021-Security Misconfiguration",
                    cweId = "CWE-345",
                    affectedComponent = "DNS TXT: $host",
                    evidence = "SPF record: $spfRecord",
                    explanationAr = "استخدام آلية +all يعني أن أي خادم على الإنترنت مصرح له بإرسال بريد باسمك، مما يبطل الغرض من حماية SPF بالكامل.",
                    explanationEn = "The '+all' directive instructs recipient servers to accept email sent from any IP address globally.",
                    impactAr = "تسهيل انتحال البريد بنسبة 100% دون أن يتم تمييزه كبريد احتيالي.",
                    impactEn = "Full vulnerability to unauthorized domain spoofing.",
                    remediationStepsAr = listOf("غيّر +all إلى -all (Hard Fail) أو ~all (Soft Fail)."),
                    remediationStepsEn = listOf("Change '+all' to '-all' or '~all'."),
                    configSnippet = "$host. IN TXT \"v=spf1 mx -all\"",
                    verificationCommand = "dig +short TXT $host",
                    references = listOf("https://tools.ietf.org/html/rfc7208"),
                    visualDiagram = VisualDiagramType.SPF_DMARC
                )
            )
        }

        // 5. Analyze DMARC finding
        if (dmarcRecord == null) {
            findings.add(
                SecurityFinding(
                    id = "DNS-DMARC-MISSING",
                    title = "Missing DMARC Policy Record",
                    titleAr = "غياب سياسة DMARC لمكافحة انتحال النطاق والإبلاغ التلقائي",
                    category = Category.DNS_EMAIL,
                    severity = Severity.MEDIUM,
                    classification = FindingClassification.CONFIRMED_MISCONFIGURATION,
                    confidence = Confidence.CONFIRMED,
                    cvssScore = 5.3,
                    cvssVector = "CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:N/I:L/A:N",
                    owaspCategory = "A05:2021-Security Misconfiguration",
                    cweId = "CWE-345",
                    affectedComponent = "DNS TXT: _dmarc.$host",
                    evidence = "No TXT record found at '_dmarc.$host'.",
                    explanationAr = "سجل DMARC يربط بين SPF و DKIM ويحدد لمستلمي البريد الإجراء الإلزامي عند فشل التحقق (حظر أو وضع في الحجر الصحي) مع إرسال تقارير خروقات.",
                    explanationEn = "DMARC verifies message authenticity via SPF/DKIM alignment and instructs receivers on enforcement (reject/quarantine).",
                    impactAr = "غياب الرقابة على محاولات تزوير النطاق وعدم حظر رسائل الاحتيال التي تنتحل صفتك.",
                    impactEn = "Lack of visibility and enforcement against phishing campaigns targeting users.",
                    remediationStepsAr = listOf(
                        "أضف سجل TXT للنطاق الفرعي _dmarc.$host.",
                        "ابدأ بسياسة مراقبة p=none ثم تدرج إلى p=quarantine أو p=reject."
                    ),
                    remediationStepsEn = listOf(
                        "Create TXT record at _dmarc.$host with policy p=quarantine or p=reject.",
                        "Configure rua/ruf mailboxes for telemetry reports."
                    ),
                    configSnippet = "_dmarc.$host. IN TXT \"v=DMARC1; p=reject; rua=mailto:dmarc-reports@$host\"",
                    verificationCommand = "dig +short TXT _dmarc.$host",
                    references = listOf("https://tools.ietf.org/html/rfc7489"),
                    visualDiagram = VisualDiagramType.SPF_DMARC
                )
            )
        } else if (dmarcRecord.contains("p=none")) {
            findings.add(
                SecurityFinding(
                    id = "DNS-DMARC-POLICY-NONE",
                    title = "DMARC Policy Set to 'none' (Monitoring Only)",
                    titleAr = "سياسة DMARC مضبوطة على 'none' دون فرض الحظر الفعلي",
                    category = Category.DNS_EMAIL,
                    severity = Severity.LOW,
                    classification = FindingClassification.INFORMATIONAL,
                    confidence = Confidence.CONFIRMED,
                    cvssScore = 3.1,
                    cvssVector = "CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:N/I:L/A:N",
                    owaspCategory = "A05:2021-Security Misconfiguration",
                    cweId = "CWE-345",
                    affectedComponent = "DNS TXT: _dmarc.$host",
                    evidence = "DMARC record: $dmarcRecord",
                    explanationAr = "سياسة 'p=none' مفيدة لجمع الإحصائيات في البداية، لكنها لا تمنع تسليم رسائل البريد المزورة إلى صناديق الوارد.",
                    explanationEn = "DMARC 'p=none' policy does not enforce rejection or quarantine of forged emails.",
                    impactAr = "استمرار إمكانية وصول الرسائل المزورة لبريد الضحايا.",
                    impactEn = "Forged emails may still be delivered to recipient inboxes.",
                    remediationStepsAr = listOf("قم بترقية سياسة DMARC إلى p=quarantine أو p=reject بعد مراجعة التقارير."),
                    remediationStepsEn = listOf("Upgrade DMARC policy from 'none' to 'quarantine' or 'reject'."),
                    configSnippet = "_dmarc.$host. IN TXT \"v=DMARC1; p=quarantine; rua=mailto:dmarc@$host\"",
                    verificationCommand = "dig +short TXT _dmarc.$host",
                    references = listOf("https://dmarc.org/"),
                    visualDiagram = VisualDiagramType.SPF_DMARC
                )
            )
        }

        val summary = "IP Addresses: ${ipList.joinToString(", ")}. SPF: ${spfRecord ?: "None"}. DMARC: ${dmarcRecord ?: "None"}."
        DnsResult(ipList, spfRecord, dmarcRecord, findings, summary)
    }
}
