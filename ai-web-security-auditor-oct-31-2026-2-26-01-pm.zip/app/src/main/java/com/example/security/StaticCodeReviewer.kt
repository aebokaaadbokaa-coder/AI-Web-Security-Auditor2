package com.example.security

import com.example.model.Severity
import com.example.model.StaticCodeFinding

object StaticCodeReviewer {

    private data class StaticRule(
        val id: String,
        val ruleName: String,
        val ruleNameAr: String,
        val severity: Severity,
        val cweId: String,
        val pattern: Regex,
        val explanationAr: String,
        val remediationAr: String,
        val maskSecret: Boolean = false
    )

    private val RULES = listOf(
        // 1. Hardcoded Secrets
        StaticRule(
            id = "SEC-01-AWS-KEY",
            ruleName = "Hardcoded AWS Access Key",
            ruleNameAr = "وجود مفتاح وصول سحابي AWS مضمن في الكود",
            severity = Severity.CRITICAL,
            cweId = "CWE-798",
            pattern = Regex("""AKIA[0-9A-Z]{16}"""),
            explanationAr = "تم رصد مفتاح AWS Access Key ثابت ومضمن صراحة في الكود، مما يعرض البنية السحابية للاختراق الفوري إذا سُرب الكود.",
            remediationAr = "انقل المفاتيح إلى متغيرات بيئة (Environment Variables) أو أداة إدارة أسرار مثل AWS Secrets Manager.",
            maskSecret = true
        ),
        StaticRule(
            id = "SEC-01-PRIVATE-KEY",
            ruleName = "Hardcoded RSA/EC Private Key",
            ruleNameAr = "تضمين مفتاح تشفير خاص في الكود المصدري",
            severity = Severity.CRITICAL,
            cweId = "CWE-312",
            pattern = Regex("""-----BEGIN (RSA |EC |OPENSSH )?PRIVATE KEY-----"""),
            explanationAr = "تضمين المفاتيح الخاصة في الكود يؤدي لكسر التشفير وإمكانية فك تشفير الاتصالات وتوقيع توكنات مزورة.",
            remediationAr = "احذف المفتاح من الكود وخزنه في KeyVault مشفر أو كملف صلاحياته مقيدة.",
            maskSecret = true
        ),
        StaticRule(
            id = "SEC-01-GENERIC-SECRET",
            ruleName = "Hardcoded API Secret or Password",
            ruleNameAr = "كلمة مرور أو رمز سري مضمن بشكل نصي صريح",
            severity = Severity.HIGH,
            cweId = "CWE-798",
            pattern = Regex("""(?i)(api[_-]?key|secret|password|passwd|auth[_-]?token)\s*=\s*['"][a-zA-Z0-9_\-\.]{8,}['"]"""),
            explanationAr = "تعيين كلمات المرور والرموز السرية كثوابت في الشيفرة المصدرية يمكن المطورين ومراجعي الكود من استخراجها.",
            remediationAr = "استخدم ملفات .env المحلية المحجوبة عن أنظمة Git ومخازن الأسرار.",
            maskSecret = true
        ),

        // 2. JWT Validation Issues
        StaticRule(
            id = "SEC-02-JWT-NONE-ALG",
            ruleName = "JWT Algorithm 'none' Allowed",
            ruleNameAr = "السماح بخوارزمية التوقيع 'none' في توكن JWT",
            severity = Severity.CRITICAL,
            cweId = "CWE-347",
            pattern = Regex("""(?i)(algorithms?\s*[:=]\s*\[?.*['"]none['"].*\]?|verify\s*[:=]\s*false)"""),
            explanationAr = "السماح بخوارزمية 'none' أو تعطيل التحقق يمكن المهاجم من تعديل بيانات التوكن وانتحال شخصية أي مستخدم بدون توقيع صحيح.",
            remediationAr = "احظر خوارزمية 'none' وافرض خوارزميات توقيع قوية مثل RS256 أو HS256 مع التحقق الإلزامي."
        ),

        // 3. Disabled TLS Certificate Validation
        StaticRule(
            id = "SEC-03-DISABLED-TLS-VERIFY",
            ruleName = "Disabled TLS Certificate Validation",
            ruleNameAr = "تعطيل التحقق من شهادة التشفير TLS / SSL",
            severity = Severity.CRITICAL,
            cweId = "CWE-295",
            pattern = Regex("""(?i)(verify\s*=\s*False|rejectUnauthorized\s*:\s*false|TrustAllCerts|ALLOW_ALL_HOSTNAME_VERIFIER|InsecureSkipVerify\s*:\s*true)"""),
            explanationAr = "تعطيل التحقق من صلاحية الشهادة يفتح الباب على مصراعيه لهجمات رجل في المنتصف (Man-in-the-Middle) وسرقة البيانات.",
            remediationAr = "فعّل التحقق الإلزامي من الشهادات الرقمية وسلسلة الثقة لجميع طلبات الشبكة."
        ),

        // 4. Unsafe eval Usage
        StaticRule(
            id = "SEC-04-UNSAFE-EVAL",
            ruleName = "Dangerous Code Evaluation (eval / Function)",
            ruleNameAr = "استخدام دوال تنفيذ الأكواد الديناميكية الخطيرة (eval)",
            severity = Severity.HIGH,
            cweId = "CWE-95",
            pattern = Regex("""\b(eval\s*\(|new\s+Function\s*\(|execScript\s*\()"""),
            explanationAr = "دالة eval تقوم بتنفيذ النصوص كشيفرة برمجية مباشرة، مما يسبب ثغرات حقن الشيفرات الخبيثة (Remote Code Execution) عند تمرير مدخلات غير مفلترة.",
            remediationAr = "استبدل eval بدوال تحليل آمنة مثل JSON.parse وتجنب بناء المنطق البرمجي ديناميكياً."
        ),

        // 5. Dangerous Command Execution
        StaticRule(
            id = "SEC-05-DANGEROUS-EXEC",
            ruleName = "Operating System Command Execution",
            ruleNameAr = "تنفيذ أوامر نظام التشغيل المباشرة (OS Command Execution)",
            severity = Severity.CRITICAL,
            cweId = "CWE-78",
            pattern = Regex("""\b(Runtime\.getRuntime\(\)\.exec\(|os\.system\(|subprocess\.Popen\(|child_process\.exec\(|shell_exec\()"""),
            explanationAr = "استدعاء أوامر نظام التشغيل باستخدام مدخلات المستخدم يتيح تنفيذ أوامر خبيثة والسيطرة على الخادم بالكامل.",
            remediationAr = "تجنب تنفيذ أوامر الطرفية، أو استخدم واجهات برمجة التطبيقات (APIs) المعزولة مع مصفوفة معلمات صارمة دون تشغيل غلاف Shell."
        ),

        // 6. SQL String Construction
        StaticRule(
            id = "SEC-06-SQL-CONCAT",
            ruleName = "Dynamic SQL Query Concatenation",
            ruleNameAr = "بناء استعلامات SQL بدمج النصوص يدوياً (خطر SQL Injection)",
            severity = Severity.HIGH,
            cweId = "CWE-89",
            pattern = Regex("""(?i)(select\s+.*\s+from\s+.*where\s+.*['"]\s*\+|\bformat\s*\(\s*['"]select\s+.*|f['"]select\s+.*\{)"""),
            explanationAr = "دمج مدخلات المستخدم في نص استعلام SQL مباشرة يسبب ثغرات حقن SQL وسرقة قواعد البيانات أو مسحها.",
            remediationAr = "استخدم الاستعلامات المجهزة المسبقة (Parameterized Queries) أو أدوات الـ ORM مثل Hibernate أو SQLAlchemy."
        ),

        // 7. Unsafe Raw HTML
        StaticRule(
            id = "SEC-07-UNSAFE-RAW-HTML",
            ruleName = "Unsafe Raw HTML / DOM Injection",
            ruleNameAr = "حقن محتوى HTML غير مفلتر (خطر XSS في المتصفح)",
            severity = Severity.MEDIUM,
            cweId = "CWE-79",
            pattern = Regex("""(?i)(\.innerHTML\s*=|dangerouslySetInnerHTML|v-html\s*=|ng-bind-html)"""),
            explanationAr = "إدراج مدخلات في عناصر HTML بدون ترميز يتيح للمهاجم تنفيذ سكربتات خبيثة (Cross-Site Scripting) في متصفح الزوار.",
            remediationAr = "استخدم خاصية textContent أو آليات القولبة الآمنة التي تعقم النصوص تلقائياً مثل DOMPurify."
        ),

        // 8. Weak Hashing
        StaticRule(
            id = "SEC-08-WEAK-HASH",
            ruleName = "Use of Cryptographically Broken Hash (MD5 / SHA-1)",
            ruleNameAr = "استخدام خوارزميات تجزئة ضعيفة ومكسورة (MD5 أو SHA1)",
            severity = Severity.MEDIUM,
            cweId = "CWE-328",
            pattern = Regex("""(?i)(MessageDigest\.getInstance\s*\(\s*['"](MD5|SHA-?1)['"]|hashlib\.(md5|sha1)\s*\()"""),
            explanationAr = "خوارزميات MD5 و SHA1 تعاني من تصادمات تشفير مثبتة عملياً ولا توفر حماية موثوقة.",
            remediationAr = "استخدم عائلة SHA-256 / SHA-512 أو خوارزميات تجزئة كلمات المرور المتخصصة (bcrypt أو Argon2)."
        ),

        // 9. Insecure Randomness
        StaticRule(
            id = "SEC-09-INSECURE-RANDOM",
            ruleName = "Use of Insecure Pseudo-Random Number Generator",
            ruleNameAr = "استخدام مولد أرقام عشوائية غير آمن تشفيرياً للرموز السرية",
            severity = Severity.LOW,
            cweId = "CWE-338",
            pattern = Regex("""\b(Math\.random\(\)|java\.util\.Random\(|random\.random\(\))"""),
            explanationAr = "المولدات القياسية مثل Math.random تعتمد على خوارزميات خطية قابلة للتخمين ولا تصلح لتوليد رموز الجلسات أو التوكنات.",
            remediationAr = "استخدم مولدات تشفير عشوائية آمنة مثل java.security.SecureRandom أو crypto.getRandomValues()."
        ),

        // 10. Debug Mode Exposure
        StaticRule(
            id = "SEC-10-DEBUG-MODE",
            ruleName = "Debug Mode Enabled in Source Code",
            ruleNameAr = "تفعيل وضع التصحيح (Debug Mode) في الكود",
            severity = Severity.MEDIUM,
            cweId = "CWE-215",
            pattern = Regex("""(?i)(DEBUG\s*=\s*True|app\.debug\s*=\s*true|NODE_ENV\s*=\s*['"]development['"])"""),
            explanationAr = "تشغيل التطبيق في وضع التصحيح يعرض مسارات الملفات والمتغيرات الحساسة ولوحات التحكم التفاعلية للعامة.",
            remediationAr = "تأكد من تعطيل وضع التصحيح في بيئة الإنتاج واعتماد متغيرات البيئة لإدارته."
        ),

        // 11. Exception Information Leakage
        StaticRule(
            id = "SEC-11-STACK-TRACE-LEAK",
            ruleName = "Exception Stack Trace Printed Directly",
            ruleNameAr = "طباعة تفاصيل الأخطاء والـ Stack Trace للواجهة",
            severity = Severity.LOW,
            cweId = "CWE-209",
            pattern = Regex("""(?i)(\.printStackTrace\(\)|display_errors\s*=\s*On|res\.send\s*\(\s*err\.stack\))"""),
            explanationAr = "طباعة الخطأ كاملاً للعميل يكشف مسارات المجلدات وإصدارات المكتبات وطبيعة قاعدة البيانات.",
            remediationAr = "سجل الأخطاء في خادم المراقبة وأرجع للمستخدم رسالة خطأ عامة ورمز خطأ مرجعي فقط."
        ),

        // 12. Open CORS Configuration
        StaticRule(
            id = "SEC-12-OPEN-CORS",
            ruleName = "Wildcard / Insecure CORS Header Configuration",
            ruleNameAr = "إعدادات CORS تسمح لأي نطاق خارجي بالوصول للموارد (*)",
            severity = Severity.HIGH,
            cweId = "CWE-942",
            pattern = Regex("""(?i)(Access-Control-Allow-Origin['"]?\s*[:=]\s*['"]\*['"]|cors\(\s*\{\s*origin\s*:\s*['"]\*['"]\s*\})"""),
            explanationAr = "إتاحة مشاركة الموارد للنجمة '*' يتيح للمواقع الخارجية قراءة البيانات الحساسة عبر متصفح الضحية.",
            remediationAr = "حدد قائمة بيضاء صريحة بالنطاقات الموثوقة بدلاً من السماح للجميع."
        ),

        // 13. Weak Cryptography
        StaticRule(
            id = "SEC-13-WEAK-CIPHER",
            ruleName = "Use of Insecure Cipher Algorithm (DES / RC4 / ECB Mode)",
            ruleNameAr = "استخدام خوارزميات أو أوضاع تشفير قديمة وضعيفة (DES أو ECB)",
            severity = Severity.HIGH,
            cweId = "CWE-327",
            pattern = Regex("""(?i)Cipher\.getInstance\s*\(\s*['"](DES|RC4|AES/ECB)"""),
            explanationAr = "خوارزميات DES و RC4 مكسورة، كما أن وضع ECB يكرر كتل التشفير مما يكشف أنماط البيانات الأصلية.",
            remediationAr = "استخدم تشفير AES في وضع GCM مع مصادقة البيانات (AES/GCM/NoPadding)."
        ),

        // 14. Path Traversal Indicators
        StaticRule(
            id = "SEC-14-PATH-TRAVERSAL",
            ruleName = "Potential Path Traversal in File Operations",
            ruleNameAr = "مؤشر لثغرة تجاوز المسار لقراءة الملفات (Path Traversal)",
            severity = Severity.HIGH,
            cweId = "CWE-22",
            pattern = Regex("""(?i)(fs\.readFile\s*\(.*req\.(query|params|body)|open\s*\(.*request\.(GET|POST)|new\s+File\s*\(.*req\.getParameter)"""),
            explanationAr = "قراءة الملفات باستخدام مسارات يرسلها المستخدم مباشرة تسمح بالرجوع للخلف باستخدام '../' وقراءة ملفات النظام مثل /etc/passwd.",
            remediationAr = "استخدم أسماء ملفات قياسية مشفرة وتأكد من أن المسار النهائي يقع ضمن المجلد المصرح به حصراً."
        ),

        // 15. Open Redirect Indicators
        StaticRule(
            id = "SEC-15-OPEN-REDIRECT",
            ruleName = "Unvalidated Redirect from User Input",
            ruleNameAr = "إعادة توجيه غير مقيدة لروابط يحددها المستخدم (Open Redirect)",
            severity = Severity.MEDIUM,
            cweId = "CWE-601",
            pattern = Regex("""(?i)(res\.redirect\s*\(.*req\.(query|params)|redirect\s*\(.*request\.(GET|POST))"""),
            explanationAr = "إعادة توجيه الزائر لرابط خارجي دون التحقق منه تتيح للمهاجمين استغلال سمعة نطاقك في حملات التصيد.",
            remediationAr = "تحقق من أن رابط التوجيه يبدأ بمسار محلي نسبي ('/') أو يطابق نطاقك المصرح به فقط."
        ),

        // 16. SSRF Indicators
        StaticRule(
            id = "SEC-16-SSRF-INDICATOR",
            ruleName = "Server-Side HTTP Request with Dynamic Input",
            ruleNameAr = "إرسال طلب HTTP من الخادم لرابط غير مفلتر (مؤشر SSRF)",
            severity = Severity.HIGH,
            cweId = "CWE-918",
            pattern = Regex("""(?i)(requests\.get\s*\(.*request\.(GET|POST)|fetch\s*\(.*req\.(query|body)|HttpClient.*execute\s*\(.*req\.getParameter)"""),
            explanationAr = "توجيه الخادم لطلب عناوين يرسلها المستخدم دون حماية يتيح الوصول للشبكات الداخلية وسحب مفاتيح الخدمات السحابية.",
            remediationAr = "طبق فحص النطاقات وعناوين IP (SSRF Guard) لحظر عناوين 127.0.0.1 والشبكات الخاصة وسحابة 169.254.169.254."
        ),

        // 17. Insecure Cookie Configuration
        StaticRule(
            id = "SEC-17-INSECURE-COOKIE",
            ruleName = "Cookie Created Without Secure / HttpOnly Flags",
            ruleNameAr = "إنشاء ملف تعريف ارتباط في الكود دون علامات الأمان",
            severity = Severity.MEDIUM,
            cweId = "CWE-614",
            pattern = Regex("""(?i)(res\.cookie\s*\([^,\)]+,\s*[^,\)]+\)|setcookie\s*\([^,\)]+,\s*[^,\)]+\))"""),
            explanationAr = "إعداد ملفات تعريف الارتباط بدون تحديد الخصائص 'httpOnly: true' و 'secure: true' يعرضها للسرقة عبر XSS.",
            remediationAr = "أضف الخيارات { httpOnly: true, secure: true, sameSite: 'lax' } دائماً لجميع الكوكيز."
        ),

        // 18. Unsafe File Upload Handling
        StaticRule(
            id = "SEC-18-UNSAFE-UPLOAD",
            ruleName = "Unrestricted File Upload Processing",
            ruleNameAr = "رفع ملفات دون فحص الامتداد ونوع المحتوى المسموح",
            severity = Severity.HIGH,
            cweId = "CWE-434",
            pattern = Regex("""(?i)(move_uploaded_file\(|file\.save\(.*file\.filename|req\.file\s*&&.*path\.join)"""),
            explanationAr = "حفظ ملفات يرفعها المستخدم دون تغيير اسمها أو فحص امتدادها بدقة يسمح برفع سكربتات ضارة (Web Shell).",
            remediationAr = "تحقق من الامتدادات عبر قائمة بيضاء صارمة وأعد تسمية الملف برمز UUID عشوائي وخزنه خارج مجلد الويب."
        )
    )

    fun reviewCode(codeContent: String, fileName: String = "SourceFile"): List<StaticCodeFinding> {
        val findings = mutableListOf<StaticCodeFinding>()
        val lines = codeContent.lines()

        for ((index, line) in lines.withIndex()) {
            val lineNumber = index + 1
            val trimmed = line.trim()
            if (trimmed.startsWith("//") || trimmed.startsWith("#") || trimmed.startsWith("/*")) {
                continue // Skip pure comments
            }

            for (rule in RULES) {
                if (rule.pattern.containsMatchIn(line)) {
                    val displaySnippet = if (rule.maskSecret) {
                        maskSensitiveData(line.trim())
                    } else {
                        line.trim().take(120)
                    }

                    findings.add(
                        StaticCodeFinding(
                            id = "${rule.id}-$lineNumber",
                            fileName = fileName,
                            lineNumber = lineNumber,
                            ruleName = rule.ruleName,
                            ruleNameAr = rule.ruleNameAr,
                            severity = rule.severity,
                            cweId = rule.cweId,
                            codeSnippet = displaySnippet,
                            explanationAr = rule.explanationAr,
                            remediationAr = rule.remediationAr
                        )
                    )
                }
            }
        }

        return findings
    }

    private fun maskSensitiveData(snippet: String): String {
        return snippet.replace(Regex("""(['"])[a-zA-Z0-9_\-\.]{4,}(['"])""")) { match ->
            val quote = match.groupValues[1]
            "${quote}******[REDACTED_SECRET]******${quote}"
        }
    }
}
