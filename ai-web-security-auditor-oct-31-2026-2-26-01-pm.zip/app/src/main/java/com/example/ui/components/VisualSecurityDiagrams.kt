package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.Block
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Http
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.OpenInBrowser
import androidx.compose.material.icons.filled.Public
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.VpnKey
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.VisualDiagramType
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.CyberCrimson
import com.example.ui.theme.CyberEmerald
import com.example.ui.theme.SeverityCritical
import com.example.ui.theme.SeverityHigh
import com.example.ui.theme.SeverityMedium

@Composable
fun SecurityDiagramViewer(
    diagramType: VisualDiagramType,
    isEnglish: Boolean,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp)),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF070E1B)),
        border = androidx.compose.foundation.BorderStroke(1.dp, CyberCyan.copy(alpha = 0.5f))
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.Shield,
                    contentDescription = null,
                    tint = CyberCyan,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = if (isEnglish) "Architectural Security Diagram" else "رسم بياني توضيحي للهندسة الأمنية",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = CyberCyan
                )
            }
            Spacer(modifier = Modifier.height(10.dp))

            when (diagramType) {
                VisualDiagramType.TLS_HANDSHAKE -> TlsHandshakeDiagram(isEnglish)
                VisualDiagramType.SECURITY_HEADERS -> SecurityHeadersDiagram(isEnglish)
                VisualDiagramType.CSP_WHITELIST -> CspWhitelistDiagram(isEnglish)
                VisualDiagramType.COOKIE_FLAGS -> CookieFlagsDiagram(isEnglish)
                VisualDiagramType.CLICKJACKING -> ClickjackingDiagram(isEnglish)
                VisualDiagramType.SPF_DMARC -> SpfDmarcDiagram(isEnglish)
                VisualDiagramType.CORS_MATRIX -> CorsMatrixDiagram(isEnglish)
                VisualDiagramType.INFO_DISCLOSURE -> InfoDisclosureDiagram(isEnglish)
                VisualDiagramType.DNS_SECURITY -> DnsSecurityDiagram(isEnglish)
                VisualDiagramType.API_SURFACE -> ApiSurfaceDiagram(isEnglish)
                VisualDiagramType.SECURITY_SCORE -> SecurityScoreGaugeDiagram(isEnglish)
            }
        }
    }
}

@Composable
fun TlsHandshakeDiagram(isEnglish: Boolean) {
    Column {
        Text(
            text = if (isEnglish) "TLS 1.3 Secure Cryptographic Handshake vs Insecure Plaintext" else "مصافحة التشفير الآمنة TLS 1.3 مقابل الاتصال غير المشفر",
            fontSize = 12.sp,
            fontWeight = FontWeight.SemiBold,
            color = MaterialTheme.colorScheme.onSurface
        )
        Spacer(modifier = Modifier.height(8.dp))
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            DiagramBox(title = "Client / Browser", sub = if (isEnglish) "Client Hello (ECDH)" else "طلب العميل", icon = Icons.Default.OpenInBrowser, color = CyberCyan)
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(imageVector = Icons.Default.Lock, contentDescription = null, tint = CyberEmerald, modifier = Modifier.size(20.dp))
                Text(text = "TLS 1.3 AES-GCM", fontSize = 10.sp, color = CyberEmerald, fontWeight = FontWeight.Bold)
                Text(text = "──── PFS Tunnel ────>", fontSize = 9.sp, color = CyberEmerald, fontFamily = FontFamily.Monospace)
            }
            DiagramBox(title = "Server / Edge", sub = if (isEnglish) "Cert & Key Share" else "شهادة السيرفر", icon = Icons.Default.Public, color = CyberEmerald)
        }
    }
}

@Composable
fun SecurityHeadersDiagram(isEnglish: Boolean) {
    Column {
        Text(
            text = if (isEnglish) "Defensive HTTP Security Headers Gateway Barrier" else "بوابة الترويسات الأمنية الدفاعية لصد الهجمات",
            fontSize = 12.sp,
            fontWeight = FontWeight.SemiBold,
            color = MaterialTheme.colorScheme.onSurface
        )
        Spacer(modifier = Modifier.height(8.dp))
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            HeaderShieldPill(name = "HSTS", desc = "HTTPS Only", active = true, modifier = Modifier.weight(1f))
            HeaderShieldPill(name = "X-Frame", desc = "Anti-Clickjack", active = true, modifier = Modifier.weight(1f))
            HeaderShieldPill(name = "CSP", desc = "Anti-XSS", active = true, modifier = Modifier.weight(1f))
            HeaderShieldPill(name = "X-Content", desc = "nosniff", active = true, modifier = Modifier.weight(1f))
        }
    }
}

@Composable
fun CspWhitelistDiagram(isEnglish: Boolean) {
    Column {
        Text(
            text = if (isEnglish) "Content-Security-Policy (CSP) Execution Boundary" else "حدود أمان سياسة المحتوى (CSP) ضد السكربتات الخبيثة",
            fontSize = 12.sp,
            fontWeight = FontWeight.SemiBold,
            color = MaterialTheme.colorScheme.onSurface
        )
        Spacer(modifier = Modifier.height(8.dp))
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Column(modifier = Modifier.weight(1f).padding(4.dp)) {
                Text(text = if (isEnglish) "✅ Allowed Sources" else "✅ المصادر المصرح بها", fontSize = 10.sp, color = CyberEmerald, fontWeight = FontWeight.Bold)
                Text(text = "• default-src 'self'\n• script-src 'nonce-...' \n• object-src 'none'", fontSize = 10.sp, color = Color.White, fontFamily = FontFamily.Monospace)
            }
            Column(modifier = Modifier.weight(1f).padding(4.dp)) {
                Text(text = if (isEnglish) "🚫 Blocked / Quarantined" else "🚫 المحظور أمنياً", fontSize = 10.sp, color = CyberCrimson, fontWeight = FontWeight.Bold)
                Text(text = "• 'unsafe-inline' XSS\n• 'unsafe-eval' RCE\n• Wildcard scripts (*)", fontSize = 10.sp, color = Color(0xFFFFB4B4), fontFamily = FontFamily.Monospace)
            }
        }
    }
}

@Composable
fun CookieFlagsDiagram(isEnglish: Boolean) {
    Column {
        Text(
            text = if (isEnglish) "Triple-Layer Cookie Defense (Secure, HttpOnly, SameSite)" else "طبقات الحماية الثلاثية لملفات تعريف الارتباط (Cookies)",
            fontSize = 12.sp,
            fontWeight = FontWeight.SemiBold,
            color = MaterialTheme.colorScheme.onSurface
        )
        Spacer(modifier = Modifier.height(8.dp))
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            Box(modifier = Modifier.weight(1f).clip(RoundedCornerShape(6.dp)).background(Color(0xFF0F261D)).border(1.dp, CyberEmerald, RoundedCornerShape(6.dp)).padding(6.dp)) {
                Column {
                    Text(text = "Secure", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = CyberEmerald)
                    Text(text = if (isEnglish) "HTTPS Transport Only" else "نقل عبر HTTPS فقط", fontSize = 9.sp, color = Color.White)
                }
            }
            Box(modifier = Modifier.weight(1f).clip(RoundedCornerShape(6.dp)).background(Color(0xFF0B2538)).border(1.dp, CyberCyan, RoundedCornerShape(6.dp)).padding(6.dp)) {
                Column {
                    Text(text = "HttpOnly", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = CyberCyan)
                    Text(text = if (isEnglish) "Blocks document.cookie" else "حجب عن JavaScript", fontSize = 9.sp, color = Color.White)
                }
            }
            Box(modifier = Modifier.weight(1f).clip(RoundedCornerShape(6.dp)).background(Color(0xFF281C06)).border(1.dp, Color(0xFFFFB300), RoundedCornerShape(6.dp)).padding(6.dp)) {
                Column {
                    Text(text = "SameSite=Lax", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color(0xFFFFB300))
                    Text(text = if (isEnglish) "Mitigates CSRF" else "حماية ضد CSRF", fontSize = 9.sp, color = Color.White)
                }
            }
        }
    }
}

@Composable
fun ClickjackingDiagram(isEnglish: Boolean) {
    Column {
        Text(
            text = if (isEnglish) "UI Redressing (Clickjacking) Attack vs Framing Restrictions" else "هجوم استدراج النقرات عبر الإطارات الخفية مقابل منع التأطير",
            fontSize = 12.sp,
            fontWeight = FontWeight.SemiBold,
            color = MaterialTheme.colorScheme.onSurface
        )
        Spacer(modifier = Modifier.height(8.dp))
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(8.dp))
                .background(Color(0xFF150A10))
                .border(1.dp, CyberCrimson, RoundedCornerShape(8.dp))
                .padding(10.dp)
        ) {
            Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(imageVector = Icons.Default.Block, contentDescription = null, tint = CyberCrimson, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(text = "X-Frame-Options: SAMEORIGIN / DENY", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = CyberCrimson)
                }
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = if (isEnglish)
                        "Prevents malicious sites from overlaying transparent iframes to hijack user clicks and transactions."
                    else
                        "يمنع المواقع الخارجية من تضمين موقعك داخل إطار غير مرئي (iframe) لخداع الزائر بالضغط على إجراءات مصرفية أو حساسة.",
                    fontSize = 10.sp,
                    color = Color.White
                )
            }
        }
    }
}

@Composable
fun SpfDmarcDiagram(isEnglish: Boolean) {
    Column {
        Text(
            text = if (isEnglish) "Email Domain Spoofing Defense: SPF & DMARC Verification Chain" else "سلسلة التحقق لمكافحة انتحال البريد: تكامل SPF وDMARC",
            fontSize = 12.sp,
            fontWeight = FontWeight.SemiBold,
            color = MaterialTheme.colorScheme.onSurface
        )
        Spacer(modifier = Modifier.height(8.dp))
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            DiagramBox(title = "Sender IP", sub = "Mail Origin", icon = Icons.Default.Email, color = CyberCyan)
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(text = "SPF check: IP ∈ TXT", fontSize = 9.sp, color = CyberEmerald, fontWeight = FontWeight.Bold)
                Text(text = "DMARC policy: p=reject", fontSize = 9.sp, color = CyberEmerald, fontWeight = FontWeight.Bold)
                Text(text = "─────────►", fontSize = 10.sp, color = CyberEmerald)
            }
            DiagramBox(title = "Receiver Inbox", sub = if (isEnglish) "Verified Authenticity" else "تم تأكيد الهوية", icon = Icons.Default.CheckCircle, color = CyberEmerald)
        }
    }
}

@Composable
fun CorsMatrixDiagram(isEnglish: Boolean) {
    Column {
        Text(
            text = if (isEnglish) "Cross-Origin Resource Sharing (CORS) Origin Boundaries" else "مصفوفة سياسات مشاركة الموارد عبر النطاقات (CORS)",
            fontSize = 12.sp,
            fontWeight = FontWeight.SemiBold,
            color = MaterialTheme.colorScheme.onSurface
        )
        Spacer(modifier = Modifier.height(8.dp))
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Box(modifier = Modifier.weight(1f).clip(RoundedCornerShape(6.dp)).background(Color(0xFF220707)).padding(6.dp)) {
                Text(text = "❌ Insecure:\nOrigin: *\nCredentials: true\n(Data Leaked)", fontSize = 10.sp, color = CyberCrimson, fontFamily = FontFamily.Monospace)
            }
            Box(modifier = Modifier.weight(1f).clip(RoundedCornerShape(6.dp)).background(Color(0xFF042111)).padding(6.dp)) {
                Text(text = "✅ Hardened:\nOrigin: trusted.com\nStrict Methods\n(Safe Isolation)", fontSize = 10.sp, color = CyberEmerald, fontFamily = FontFamily.Monospace)
            }
        }
    }
}

@Composable
fun InfoDisclosureDiagram(isEnglish: Boolean) {
    Column {
        Text(
            text = if (isEnglish) "Technology Fingerprinting & Version Obfuscation" else "إخفاء ترويسات الخادم وتقنيات التشغيل لمنع الاستطلاع",
            fontSize = 12.sp,
            fontWeight = FontWeight.SemiBold,
            color = MaterialTheme.colorScheme.onSurface
        )
        Spacer(modifier = Modifier.height(8.dp))
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Box(modifier = Modifier.weight(1f).clip(RoundedCornerShape(6.dp)).background(Color(0xFF1E1405)).padding(6.dp)) {
                Text(text = "⚠️ Exposed Banner:\nServer: nginx/1.18.0\nX-Powered-By: PHP/7.4\n(Targeted CVEs)", fontSize = 10.sp, color = Color(0xFFFFB300), fontFamily = FontFamily.Monospace)
            }
            Box(modifier = Modifier.weight(1f).clip(RoundedCornerShape(6.dp)).background(Color(0xFF071C26)).padding(6.dp)) {
                Text(text = "🛡️ Obfuscated:\nserver_tokens off;\nNo X-Powered-By\n(Adversary Blinded)", fontSize = 10.sp, color = CyberCyan, fontFamily = FontFamily.Monospace)
            }
        }
    }
}

@Composable
fun DnsSecurityDiagram(isEnglish: Boolean) {
    Column {
        Text(
            text = if (isEnglish) "DNS Resolution Chain & SSRF Invalidation Filter" else "سلسلة استعلامات DNS مع مرشح حظر SSRF التلقائي",
            fontSize = 12.sp,
            fontWeight = FontWeight.SemiBold,
            color = MaterialTheme.colorScheme.onSurface
        )
        Spacer(modifier = Modifier.height(8.dp))
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
            Box(modifier = Modifier.clip(RoundedCornerShape(6.dp)).background(Color(0xFF0C192E)).padding(6.dp)) {
                Text(text = "DNS Query", fontSize = 10.sp, color = CyberCyan, fontWeight = FontWeight.Bold)
            }
            Text(text = " ──► ", color = CyberCyan, fontSize = 10.sp)
            Box(modifier = Modifier.clip(RoundedCornerShape(6.dp)).background(Color(0xFF1E0A10)).padding(6.dp)) {
                Text(text = "SSRF Guard Check\n(Reject 127.0.0.1, RFC1918)", fontSize = 9.sp, color = CyberCrimson)
            }
            Text(text = " ──► ", color = CyberEmerald, fontSize = 10.sp)
            Box(modifier = Modifier.clip(RoundedCornerShape(6.dp)).background(Color(0xFF052414)).padding(6.dp)) {
                Text(text = "Public IP (Audited)", fontSize = 10.sp, color = CyberEmerald, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
fun ApiSurfaceDiagram(isEnglish: Boolean) {
    Column {
        Text(
            text = if (isEnglish) "Safe Defensive API Surface Probe (Read-Only Boundaries)" else "حدود فحص سطح واجهات API (طلبات قراءة آمنة فقط)",
            fontSize = 12.sp,
            fontWeight = FontWeight.SemiBold,
            color = MaterialTheme.colorScheme.onSurface
        )
        Spacer(modifier = Modifier.height(8.dp))
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Box(modifier = Modifier.weight(1f).clip(RoundedCornerShape(6.dp)).background(Color(0xFF072115)).padding(6.dp)) {
                Text(text = "✅ Allowed:\n• HEAD / OPTIONS\n• GET /robots.txt\n• GET /openapi.json", fontSize = 10.sp, color = CyberEmerald, fontFamily = FontFamily.Monospace)
            }
            Box(modifier = Modifier.weight(1f).clip(RoundedCornerShape(6.dp)).background(Color(0xFF2E0909)).padding(6.dp)) {
                Text(text = "🚫 Forbidden (Strict):\n• POST / DELETE / PUT\n• Password Brute-Force\n• Auth Token Replay", fontSize = 10.sp, color = CyberCrimson, fontFamily = FontFamily.Monospace)
            }
        }
    }
}

@Composable
fun SecurityScoreGaugeDiagram(isEnglish: Boolean) {
    Column {
        Text(
            text = if (isEnglish) "Defensive Security Risk Score Calculation Formula" else "معادلة وزن المخاطر واحتساب الدرجة الأمنية (0 - 100)",
            fontSize = 12.sp,
            fontWeight = FontWeight.SemiBold,
            color = MaterialTheme.colorScheme.onSurface
        )
        Spacer(modifier = Modifier.height(8.dp))
        Text(
            text = "Score = 100 - (Critical × 25) - (High × 15) - (Medium × 8) - (Low × 3)\nGrade A+ (95-100) • Grade A (85-94) • Grade B (75-84) • Grade C (60-74) • Grade F (<45)",
            fontSize = 10.sp,
            fontFamily = FontFamily.Monospace,
            color = CyberCyan
        )
    }
}

@Composable
private fun DiagramBox(title: String, sub: String, icon: androidx.compose.ui.graphics.vector.ImageVector, color: Color) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(8.dp))
            .background(color.copy(alpha = 0.15f))
            .border(1.dp, color, RoundedCornerShape(8.dp))
            .padding(8.dp)
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(imageVector = icon, contentDescription = null, tint = color, modifier = Modifier.size(20.dp))
            Text(text = title, fontSize = 10.sp, fontWeight = FontWeight.Bold, color = color)
            Text(text = sub, fontSize = 9.sp, color = Color.White)
        }
    }
}

@Composable
private fun HeaderShieldPill(name: String, desc: String, active: Boolean, modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(6.dp))
            .background(Color(0xFF061B28))
            .border(1.dp, CyberCyan, RoundedCornerShape(6.dp))
            .padding(6.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(text = name, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = CyberCyan)
            Text(text = desc, fontSize = 8.sp, color = Color.White, textAlign = TextAlign.Center)
        }
    }
}
