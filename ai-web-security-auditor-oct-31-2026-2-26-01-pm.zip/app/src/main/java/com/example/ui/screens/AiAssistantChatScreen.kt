package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Lightbulb
import androidx.compose.material.icons.filled.Send
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.SuggestionChip
import androidx.compose.material3.SuggestionChipDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.AssistantMessage
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.CyberEmerald
import com.example.ui.viewmodel.AuditorViewModel
import kotlinx.coroutines.launch

@Composable
fun AiAssistantChatScreen(
    viewModel: AuditorViewModel,
    modifier: Modifier = Modifier
) {
    val currentSummary by viewModel.currentSummary.collectAsState()
    val isEnglish by viewModel.isEnglish.collectAsState()
    val coroutineScope = rememberCoroutineScope()
    val listState = rememberLazyListState()

    var userPrompt by remember { mutableStateOf("") }
    val messages = remember {
        mutableStateListOf(
            AssistantMessage(
                id = "welcome",
                isUser = false,
                text = if (isEnglish)
                    "Hello! I am your AI Web Security Advisor. I can analyze your active scan results, explain CVSS scores, provide tailored Nginx/Apache configs, or clarify the difference between a Misconfiguration and a Confirmed Vulnerability."
                else
                    "أهلاً بك! أنا مستشارك الأمني الذكي. يمكنني شرح نتائج الفحص الحالي، توضيح درجات الخطورة وCVSS، اقتراح أكواد إصلاح مخصصة لخوادم Nginx و Apache، أو شرح الفرق بين خطأ الإعداد والثغرة المؤكدة استناداً للأدلة الفعلية."
            )
        )
    }

    LaunchedEffect(messages.size) {
        if (messages.isNotEmpty()) {
            listState.animateScrollToItem(messages.size - 1)
        }
    }

    fun handleSend(text: String) {
        if (text.isBlank()) return
        messages.add(AssistantMessage(id = System.currentTimeMillis().toString(), isUser = true, text = text))
        userPrompt = ""

        // Generate factual, context-aware security assistant response
        val responseText = generateAssistantAnswer(text, currentSummary, isEnglish)
        messages.add(AssistantMessage(id = (System.currentTimeMillis() + 1).toString(), isUser = false, text = responseText))
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp)
    ) {
        Spacer(modifier = Modifier.height(8.dp))

        // Top Info Card
        Card(
            modifier = Modifier.fillMaxWidth().testTag("ai_assistant_header"),
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
            border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
        ) {
            Row(
                modifier = Modifier.padding(12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(MaterialTheme.colorScheme.primaryContainer),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(imageVector = Icons.Default.AutoAwesome, contentDescription = null, tint = CyberCyan)
                }
                Spacer(modifier = Modifier.width(10.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = if (isEnglish) "AI Security Intelligence Advisor" else "المستشار الأمني الذكي (AI Security Advisor)",
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = currentSummary?.let { "الهدف المفحوص: ${it.scannedHost} (الدرجة: ${it.overallGrade})" }
                            ?: (if (isEnglish) "No active scan selected (general advice available)" else "لا يوجد فحص نشط حالياً (الاستشارات العامة متاحة)"),
                        fontSize = 11.sp,
                        color = CyberCyan
                    )
                }
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(6.dp))
                        .background(CyberEmerald.copy(alpha = 0.15f))
                        .border(1.dp, CyberEmerald, RoundedCornerShape(6.dp))
                        .padding(horizontal = 6.dp, vertical = 3.dp)
                ) {
                    Text(
                        text = if (isEnglish) "Offline Logic" else "محلي دقيق",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = CyberEmerald
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Quick Suggestion Chips
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            val suggestions = if (isEnglish) {
                listOf("Explain Differences", "HSTS Best Practice", "Summarize Risks")
            } else {
                listOf("الفرق بين سوء الإعداد والثغرة", "أفضل إعداد لـ CSP", "ملخص المخاطر الحالية")
            }

            suggestions.forEach { suggestion ->
                SuggestionChip(
                    onClick = { handleSend(suggestion) },
                    label = { Text(suggestion, fontSize = 10.sp) },
                    colors = SuggestionChipDefaults.suggestionChipColors(
                        containerColor = MaterialTheme.colorScheme.surface,
                        labelColor = CyberCyan
                    ),
                    border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
                )
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Chat Messages List
        LazyColumn(
            state = listState,
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(messages, key = { it.id }) { msg ->
                val bubbleColor = if (msg.isUser) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surface
                val align = if (msg.isUser) Alignment.End else Alignment.Start

                Column(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalAlignment = align
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth(0.88f)
                            .clip(
                                RoundedCornerShape(
                                    topStart = 12.dp,
                                    topEnd = 12.dp,
                                    bottomStart = if (msg.isUser) 12.dp else 2.dp,
                                    bottomEnd = if (msg.isUser) 2.dp else 12.dp
                                )
                            )
                            .background(bubbleColor)
                            .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(12.dp))
                            .padding(12.dp)
                    ) {
                        Text(
                            text = msg.text,
                            fontSize = 12.sp,
                            lineHeight = 18.sp,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Chat Input Box
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedTextField(
                value = userPrompt,
                onValueChange = { userPrompt = it },
                modifier = Modifier
                    .weight(1f)
                    .testTag("ai_assistant_input"),
                placeholder = { Text(if (isEnglish) "Ask about findings, remediation, CVSS..." else "اسأل عن نتائج الفحص أو حلول الترويسات...") },
                singleLine = true,
                shape = RoundedCornerShape(10.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = CyberCyan,
                    unfocusedBorderColor = MaterialTheme.colorScheme.outline
                )
            )
            Spacer(modifier = Modifier.width(8.dp))
            IconButton(
                onClick = { handleSend(userPrompt) },
                modifier = Modifier
                    .size(46.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(CyberCyan)
                    .testTag("ai_assistant_send_button")
            ) {
                Icon(imageVector = Icons.Default.Send, contentDescription = "Send", tint = Color.Black)
            }
        }
    }
}

private fun generateAssistantAnswer(prompt: String, summary: com.example.model.AuditSummary?, isEnglish: Boolean): String {
    val lower = prompt.lowercase()

    // 1. Classification Hierarchy: Misconfiguration vs Potential vs Confirmed
    if (lower.contains("فرق") || lower.contains("difference") || lower.contains("misconfiguration")) {
        return if (isEnglish) {
            "🔍 Classification Hierarchy:\n\n1. Confirmed Misconfiguration: An insecure configuration verified directly by evidence (e.g. missing HSTS, missing X-Frame-Options, or verbose server tokens). It weakens defense-in-depth but does not guarantee immediate exploitability.\n\n2. Potential Vulnerability: An indicator that could be leveraged under specific prerequisites (e.g. permissive CORS or lack of SameSite cookies).\n\n3. Confirmed Vulnerability: A proven flaw with demonstrable exploit path and unauthorized state alteration or data leak."
        } else {
            "🔍 مراتب التصنيف الأمني في التطبيق:\n\n1. خطأ إعداد مؤكد (Confirmed Misconfiguration): إعداد ضعيف مثبت بدليل قاطع (مثل غياب HSTS أو كشف إصدار السيرفر). يضعف الحماية الدفاعية لكنه لا يعني بالضرورة وجود استغلال ناجح.\n\n2. ثغرة أمنية محتملة (Potential Vulnerability): مؤشر أمني قد يؤدي لاختراق في حال توفر شروط إضافية (مثل CORS غير المقيد أو كوكيز تفتقر لـ SameSite).\n\n3. ثغرة أمنية مؤكدة (Confirmed Vulnerability): ثغرة ثبت أثرها الضار عملياً بنتيجة قابلة للتحقق دون افتراضات تخمينية."
        }
    }

    // 2. Questions about CVE & Hallucination Prevention
    if (lower.contains("cve") || lower.contains("تلفيق") || lower.contains("وهمي") || lower.contains("hallucinat")) {
        return if (isEnglish) {
            "🛡️ Zero Synthetic CVE Policy:\n\nMissing headers and weak TLS ciphers are categorized under CWE (Common Weakness Enumeration) like CWE-523 (HSTS) and CWE-1021 (Anti-Clickjacking), NOT CVE identifiers.\n\nThis engine never generates or hallucinates synthetic CVE numbers. CVEs are only referenced if a specific software version is conclusively identified in the server banner and matches the official NVD database."
        } else {
            "🛡️ سياسة حظر اختلاق أرقام CVE الوهمية (Zero Hallucination):\n\nغياب الترويسات الأمنية أو ضعف تشفير TLS يصنف ضمن معايير CWE (مثل CWE-523 لغياب HSTS و CWE-1021 لغياب X-Frame-Options)، وليس كأرقام CVE.\n\nيلتزم المستشار بعدم اختراع أي رقم CVE وهمي على الإطلاق. تُذكر أرقام CVE فقط إذا رُصد إصدار برمجي محدد مطابق لقواعد بيانات NVD الرسمية."
        }
    }

    // 3. Explaining Evidence from active scan
    if (lower.contains("evidence") || lower.contains("دليل") || lower.contains("برهان")) {
        if (summary == null || summary.findings.isEmpty()) {
            return if (isEnglish) {
                "No scan evidence is loaded. Perform a scan or load a history record to inspect real HTTP headers and TLS certificates."
            } else {
                "لا توجد أدلة فحص محملة حالياً. يرجى فحص نطاق أو فتح سجل سابق لعرض ترويسات HTTP وشهادات TLS المسجلة."
            }
        }
        val topFindings = summary.findings.take(3)
        val sb = StringBuilder()
        if (isEnglish) {
            sb.append("📋 Real Technical Evidence from Scan of ${summary.scannedHost}:\n\n")
            topFindings.forEach { f ->
                sb.append("• [${f.title}]: ${f.evidence}\n  (Component: ${f.affectedComponent})\n\n")
            }
        } else {
            sb.append("📋 الأدلة التقنية الفعلية المرصودة لموقع ${summary.scannedHost}:\n\n")
            topFindings.forEach { f ->
                sb.append("• [${f.titleAr}]: ${f.evidence}\n  (المكون المتأثر: ${f.affectedComponent})\n\n")
            }
        }
        return sb.toString().trim()
    }

    // 4. Offline mode / Connection status inquiry
    if (lower.contains("offline") || lower.contains("محلي") || lower.contains("اتصال") || lower.contains("internet") || lower.contains("إنترنت")) {
        return if (isEnglish) {
            "⚙️ Operating Mode: Deterministic Local Offline Engine.\n\nThe advisor operates entirely on device using codified OWASP/ASVS security rules and live scan findings. It requires zero cloud LLM internet connectivity to deliver accurate, reproducible remediation advice."
        } else {
            "⚙️ وضع التشغيل: محرك استدلال محلي يعمل دون اتصال إنترنت (Offline Deterministic Engine).\n\nيعتمد المستشار على قواعد OWASP و ASVS المدمجة محلياً ونتائج الفحص الفعلية، ولا يحتاج إلى الاتصال بسيرفرات ذكاء اصطناعي خارجية لتقديم النصائح وأكواد الإصلاح الدقيقة."
        }
    }

    if (lower.contains("csp") || lower.contains("محتوى")) {
        return if (isEnglish) {
            "🛡️ Content-Security-Policy (CSP) Best Practice:\n\nBegin with a strict baseline:\n`Content-Security-Policy: default-src 'self'; script-src 'self' 'nonce-RANDOM'; object-src 'none'; base-uri 'self'; frame-ancestors 'self';`\n\nAvoid 'unsafe-inline' and 'unsafe-eval' because they defeat primary XSS mitigations."
        } else {
            "🛡️ أفضل ممارسات سياسة أمان المحتوى (CSP):\n\nابدأ بسياسة صارمة:\n`add_header Content-Security-Policy \"default-src 'self'; script-src 'self'; object-src 'none'; base-uri 'self'; frame-ancestors 'self';\" always;`\n\nتجنب استخدام 'unsafe-inline' و 'unsafe-eval' لأنها تبطل الحماية الأساسية ضد هجمات حقن السكربتات XSS."
        }
    }

    if (summary != null) {
        val criticals = summary.criticalCount
        val highs = summary.highCount
        val host = summary.scannedHost
        return if (isEnglish) {
            "📊 Analysis for $host (Score: ${summary.score}/100 - Grade: ${summary.overallGrade}):\n\nFound $criticals critical and $highs high severity findings. The primary risks relate to missing transport enforcement headers and transport confidentiality. Immediate focus: implement HSTS with preload and configure CSP default-src 'self'."
        } else {
            "📊 التحليل المخصص للموقع (${host}):\n\nحصل الموقع على درجة ${summary.score}/100 وتقييم ${summary.overallGrade}. تم رصد (${criticals}) ثغرات حرجة و (${highs}) ثغرات مرتفعة.\n\nالأولوية القصوى للمعالجة:\n1. تفعيل ترويسة HSTS لفرض تشفير HTTPS دائماً.\n2. تطبيق ترويسة CSP وسياسة أمان ملفات تعريف الارتباط (Secure و HttpOnly)."
        }
    }

    return if (isEnglish) {
        "To get contextual analysis, enter a domain in the Auditor tab and start a scan. I will inspect the real headers, TLS handshake, and DNS spoofing records without any synthetic data."
    } else {
        "للحصول على استشارة دقيقة ومخصصة لموقعك، أدخل رابط الموقع في تبويب الفحص واضغط على بدء الفحص، وسأقوم بتحليل النتائج الفعلية وتجهيز أكواد الإصلاح المباشرة."
    }
}
