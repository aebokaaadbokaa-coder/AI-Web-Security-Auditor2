package com.example.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Security
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.model.Category
import com.example.model.SecurityFinding
import com.example.model.Severity
import com.example.model.VisualDiagramType
import com.example.ui.components.SecurityDiagramViewer
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.CyberEmerald
import com.example.ui.theme.SeverityCritical
import com.example.ui.theme.SeverityHigh
import com.example.ui.theme.SeverityInfo
import com.example.ui.theme.SeverityLow
import com.example.ui.theme.SeverityMedium

@Composable
fun FindingDetailDialog(
    finding: SecurityFinding,
    isEnglish: Boolean,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    var selectedTech by remember { mutableStateOf("Nginx") }

    val severityColor = when (finding.severity) {
        Severity.CRITICAL -> SeverityCritical
        Severity.HIGH -> SeverityHigh
        Severity.MEDIUM -> SeverityMedium
        Severity.LOW -> SeverityLow
        Severity.INFO -> SeverityInfo
    }

    val resolvedDiagram = finding.visualDiagram ?: when (finding.category) {
        Category.TLS_SSL -> VisualDiagramType.TLS_HANDSHAKE
        Category.SECURITY_HEADERS -> if (finding.id.contains("CSP")) VisualDiagramType.CSP_WHITELIST else if (finding.id.contains("FRAME")) VisualDiagramType.CLICKJACKING else VisualDiagramType.SECURITY_HEADERS
        Category.COOKIES -> VisualDiagramType.COOKIE_FLAGS
        Category.CORS -> VisualDiagramType.CORS_MATRIX
        Category.DNS_EMAIL -> VisualDiagramType.SPF_DMARC
        Category.INFO_DISCLOSURE -> VisualDiagramType.INFO_DISCLOSURE
        Category.STATIC_CODE -> VisualDiagramType.SECURITY_HEADERS
        Category.ARCHITECTURE -> VisualDiagramType.API_SURFACE
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth(0.95f)
                .padding(vertical = 20.dp)
                .clip(RoundedCornerShape(16.dp))
                .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(16.dp))
                .testTag("finding_detail_dialog"),
            color = MaterialTheme.colorScheme.surface
        ) {
            Column(
                modifier = Modifier
                    .padding(18.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                // Top Header Row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(severityColor)
                                .padding(horizontal = 8.dp, vertical = 3.dp)
                        ) {
                            Text(
                                text = if (isEnglish) finding.severity.labelEn else finding.severity.labelAr,
                                color = Color.Black,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        Spacer(modifier = Modifier.width(6.dp))
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(MaterialTheme.colorScheme.surfaceVariant)
                                .padding(horizontal = 8.dp, vertical = 3.dp)
                        ) {
                            Text(
                                text = if (isEnglish) finding.classification.labelEn else finding.classification.labelAr,
                                color = CyberCyan,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    IconButton(onClick = onDismiss, modifier = Modifier.testTag("close_detail_button")) {
                        Icon(imageVector = Icons.Default.Close, contentDescription = "Close", tint = MaterialTheme.colorScheme.onSurface)
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Title
                Text(
                    text = if (isEnglish) finding.title else finding.titleAr,
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Text(
                    text = "ID: ${finding.id} • ${finding.category.labelAr}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                Spacer(modifier = Modifier.height(14.dp))

                // Security Diagram
                SecurityDiagramViewer(
                    diagramType = resolvedDiagram,
                    isEnglish = isEnglish
                )

                Spacer(modifier = Modifier.height(14.dp))

                // Metadata Row (OWASP, CWE, Confidence, CVSS)
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .background(MaterialTheme.colorScheme.surfaceVariant)
                        .padding(10.dp),
                    horizontalArrangement = Arrangement.SpaceAround
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(text = "OWASP", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text(text = finding.owaspCategory, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = CyberCyan)
                    }
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(text = "CWE", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text(text = finding.cweId, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = CyberEmerald)
                    }
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(text = "CVSS v3.1", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text(text = "${finding.cvssScore ?: "N/A"}", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = severityColor)
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Affected Component & Evidence
                SectionTitle(title = if (isEnglish) "Affected Component" else "المكون المتأثر")
                CodeCard(text = finding.affectedComponent)

                Spacer(modifier = Modifier.height(10.dp))

                SectionTitle(title = if (isEnglish) "Observed Evidence" else "الدليل الفعلي المرصود (Technical Evidence)")
                CodeCard(text = finding.evidence, highlightColor = CyberCyan)

                Spacer(modifier = Modifier.height(14.dp))

                // Explanation
                SectionTitle(title = if (isEnglish) "Why is this important?" else "لماذا تعتبر هذه المشكلة مهمة؟")
                Text(
                    text = if (isEnglish) finding.explanationEn else finding.explanationAr,
                    fontSize = 13.sp,
                    lineHeight = 18.sp,
                    color = MaterialTheme.colorScheme.onSurface
                )

                Spacer(modifier = Modifier.height(12.dp))

                // Impact
                SectionTitle(title = if (isEnglish) "What could happen? (Impact)" else "ما الذي يمكن أن يحدث بسببها؟ (الأثر والمخاطر)")
                Text(
                    text = if (isEnglish) finding.impactEn else finding.impactAr,
                    fontSize = 13.sp,
                    lineHeight = 18.sp,
                    color = MaterialTheme.colorScheme.error
                )

                Spacer(modifier = Modifier.height(16.dp))

                // Visual Fix Guide Header
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(imageVector = Icons.Default.Build, contentDescription = null, tint = CyberEmerald, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = if (isEnglish) "Visual Fix Guide & Technology Snippets" else "دليل الإصلاح والتصحيح حسب التقنية (View Fix)",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = CyberEmerald
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Technology Switcher Chips (Nginx, Apache, Express, PHP, DNS)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    listOf("Nginx", "Apache", "Express", "PHP", "DNS").forEach { tech ->
                        FilterChip(
                            selected = selectedTech == tech,
                            onClick = { selectedTech = tech },
                            label = { Text(tech, fontSize = 11.sp) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = CyberCyan,
                                selectedLabelColor = Color.Black
                            )
                        )
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                val tailoredSnippet = getTailoredCodeSnippet(finding, selectedTech)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(text = "$selectedTech Configuration:", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    IconButton(
                        onClick = { copyToClipboard(context, "$selectedTech Snippet", tailoredSnippet) },
                        modifier = Modifier.size(24.dp)
                    ) {
                        Icon(imageVector = Icons.Default.ContentCopy, contentDescription = "Copy", tint = CyberCyan, modifier = Modifier.size(16.dp))
                    }
                }
                CodeCard(text = tailoredSnippet, highlightColor = Color(0xFFA7F3D0))

                Spacer(modifier = Modifier.height(14.dp))

                // Remediation Steps
                SectionTitle(title = if (isEnglish) "Step-by-Step Remediation" else "خطوات الإصلاح المقترحة")
                val steps = if (isEnglish) finding.remediationStepsEn else finding.remediationStepsAr
                steps.forEachIndexed { index, step ->
                    Row(
                        modifier = Modifier.padding(vertical = 2.dp),
                        verticalAlignment = Alignment.Top
                    ) {
                        Text(text = "${index + 1}. ", fontWeight = FontWeight.Bold, color = CyberEmerald, fontSize = 13.sp)
                        Text(text = step, fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurface)
                    }
                }

                if (finding.verificationCommand.isNotBlank()) {
                    Spacer(modifier = Modifier.height(12.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        SectionTitle(title = if (isEnglish) "Post-Fix Re-Test Verification Command" else "طريقة إعادة الفحص والتحقق بعد الإصلاح")
                        IconButton(
                            onClick = { copyToClipboard(context, "Command", finding.verificationCommand) },
                            modifier = Modifier.size(24.dp)
                        ) {
                            Icon(imageVector = Icons.Default.ContentCopy, contentDescription = "Copy", tint = CyberCyan, modifier = Modifier.size(16.dp))
                        }
                    }
                    CodeCard(text = finding.verificationCommand, highlightColor = CyberCyan)
                }

                Spacer(modifier = Modifier.height(20.dp))

                Button(
                    onClick = onDismiss,
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(8.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
                ) {
                    Text(text = if (isEnglish) "Close Window" else "إغلاق النافذة", color = MaterialTheme.colorScheme.onPrimaryContainer, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

private fun getTailoredCodeSnippet(finding: SecurityFinding, tech: String): String {
    return when (tech) {
        "Apache" -> when (finding.id) {
            "HSTS-MISSING" -> "Header always set Strict-Transport-Security \"max-age=31536000; includeSubDomains; preload\""
            "CSP-MISSING" -> "Header set Content-Security-Policy \"default-src 'self'; script-src 'self'; object-src 'none';\""
            "X-FRAME-OPTIONS-MISSING" -> "Header always append X-Frame-Options SAMEORIGIN"
            "X-CONTENT-TYPE-OPTIONS-MISSING" -> "Header set X-Content-Type-Options nosniff"
            "SERVER-BANNER-DISCLOSURE" -> "ServerTokens Prod\nServerSignature Off"
            else -> finding.configSnippet.ifBlank { "# Consult Apache documentation for ${finding.id}" }
        }
        "Express" -> when (finding.id) {
            "HSTS-MISSING", "CSP-MISSING", "X-FRAME-OPTIONS-MISSING", "X-CONTENT-TYPE-OPTIONS-MISSING" ->
                "// npm install helmet\nconst helmet = require('helmet');\napp.use(helmet());"
            "SERVER-BANNER-DISCLOSURE", "X-POWERED-BY-DISCLOSURE" ->
                "app.disable('x-powered-by');"
            else -> finding.configSnippet
        }
        "PHP" -> when (finding.id) {
            "HSTS-MISSING" -> "header(\"Strict-Transport-Security: max-age=31536000; includeSubDomains; preload\");"
            "CSP-MISSING" -> "header(\"Content-Security-Policy: default-src 'self'; script-src 'self';\");"
            "X-FRAME-OPTIONS-MISSING" -> "header(\"X-Frame-Options: SAMEORIGIN\");"
            "X-CONTENT-TYPE-OPTIONS-MISSING" -> "header(\"X-Content-Type-Options: nosniff\");"
            "X-POWERED-BY-DISCLOSURE" -> "; php.ini:\nexpose_php = Off"
            else -> finding.configSnippet
        }
        "DNS" -> when (finding.id) {
            "DNS-SPF-MISSING" -> "@ IN TXT \"v=spf1 include:_spf.example.com -all\""
            "DNS-DMARC-MISSING" -> "_dmarc IN TXT \"v=DMARC1; p=reject; rua=mailto:dmarc-reports@example.com\""
            else -> finding.configSnippet
        }
        else -> finding.configSnippet.ifBlank { "# Nginx configuration:\nadd_header ${finding.affectedComponent} \"[secure_value]\" always;" }
    }
}

@Composable
private fun SectionTitle(title: String) {
    Text(
        text = title,
        fontSize = 12.sp,
        fontWeight = FontWeight.Bold,
        color = MaterialTheme.colorScheme.onSurfaceVariant
    )
    Spacer(modifier = Modifier.height(4.dp))
}

@Composable
private fun CodeCard(text: String, highlightColor: Color = Color.White) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(8.dp))
            .background(Color(0xFF070E1A))
            .border(1.dp, Color(0xFF1B2B48), RoundedCornerShape(8.dp))
            .padding(10.dp)
    ) {
        Text(
            text = text,
            fontFamily = FontFamily.Monospace,
            fontSize = 11.sp,
            color = highlightColor
        )
    }
}

private fun copyToClipboard(context: Context, label: String, text: String) {
    val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
    val clip = ClipData.newPlainText(label, text)
    clipboard.setPrimaryClip(clip)
    Toast.makeText(context, "تم النسخ إلى الحافظة بنجاح", Toast.LENGTH_SHORT).show()
}
