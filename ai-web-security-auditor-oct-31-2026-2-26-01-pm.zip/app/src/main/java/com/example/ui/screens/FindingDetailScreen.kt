package com.example.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Security
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.Category
import com.example.model.SecurityFinding
import com.example.model.Severity
import com.example.model.VisualDiagramType
import com.example.ui.components.SecurityDiagramViewer
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.CyberEmerald
import com.example.ui.theme.SeverityCritical
import com.example.ui.theme.SeverityHigh
import com.example.ui.theme.SeverityInfo
import com.example.ui.theme.SeverityLow
import com.example.ui.theme.SeverityMedium
import com.example.ui.viewmodel.AppScreen
import com.example.ui.viewmodel.AuditorViewModel

@Composable
fun FindingDetailScreen(
    viewModel: AuditorViewModel,
    modifier: Modifier = Modifier
) {
    val selectedFinding by viewModel.selectedFinding.collectAsState()
    val isEnglish by viewModel.isEnglish.collectAsState()
    val context = LocalContext.current

    if (selectedFinding == null) {
        Box(
            modifier = modifier.fillMaxSize(),
            contentAlignment = Alignment.Center
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.padding(24.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Security,
                    contentDescription = null,
                    tint = CyberCyan,
                    modifier = Modifier.size(56.dp)
                )
                Spacer(modifier = Modifier.height(16.dp))
                Text(
                    text = if (isEnglish) "No finding selected. Select a finding from the Findings list to view full details and remediation."
                    else "لم يتم اختيار ثغرة. يرجى اختيار ثغرة من قائمة نتائج الفحص للاطلاع على التفاصيل والحلول.",
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    fontSize = 14.sp
                )
                Spacer(modifier = Modifier.height(16.dp))
                Button(
                    onClick = { viewModel.navigateTo(AppScreen.FINDINGS) },
                    colors = ButtonDefaults.buttonColors(containerColor = CyberCyan),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.testTag("nav_to_findings_button")
                ) {
                    Text(
                        text = if (isEnglish) "Go to Findings" else "الانتقال إلى نتائج الفحص",
                        color = Color.Black,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
        return
    }

    val finding = selectedFinding!!
    var selectedTech by remember { mutableStateOf("Nginx") }

    val severityColor = when (finding.severity) {
        Severity.CRITICAL -> SeverityCritical
        Severity.HIGH -> SeverityHigh
        Severity.MEDIUM -> SeverityMedium
        Severity.LOW -> SeverityLow
        Severity.INFO -> SeverityInfo
    }

    val resolvedDiagram = finding.visualDiagram ?: when (finding.category) {
        Category.TLS_SSL -> VisualDiagramType.TLS_HANDSHAKE
        Category.SECURITY_HEADERS -> if (finding.id.contains("CSP")) VisualDiagramType.CSP_WHITELIST else if (finding.id.contains("FRAME")) VisualDiagramType.CLICKJACKING else VisualDiagramType.SECURITY_HEADERS
        Category.COOKIES -> VisualDiagramType.COOKIE_FLAGS
        Category.CORS -> VisualDiagramType.CORS_MATRIX
        Category.DNS_EMAIL -> VisualDiagramType.SPF_DMARC
        Category.INFO_DISCLOSURE -> VisualDiagramType.INFO_DISCLOSURE
        Category.STATIC_CODE -> VisualDiagramType.SECURITY_HEADERS
        Category.ARCHITECTURE -> VisualDiagramType.API_SURFACE
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Spacer(modifier = Modifier.height(8.dp))

            // Top Row Back
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                IconButton(
                    onClick = { viewModel.navigateTo(AppScreen.FINDINGS) },
                    modifier = Modifier.testTag("back_to_findings_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.ArrowBack,
                        contentDescription = "Back",
                        tint = CyberCyan
                    )
                }
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = if (isEnglish) "Remediation & Evidence" else "دليل الإصلاح والأدلة الفنية",
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp,
                    color = MaterialTheme.colorScheme.onSurface
                )
            }
        }

        // Title and Severity Header Card
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("finding_detail_header_card"),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                border = androidx.compose.foundation.BorderStroke(1.dp, severityColor)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(severityColor)
                                .padding(horizontal = 10.dp, vertical = 4.dp)
                        ) {
                            Text(
                                text = if (isEnglish) finding.severity.labelEn else finding.severity.labelAr,
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp,
                                color = Color.Black
                            )
                        }

                        if (finding.cvssScore != null) {
                            Text(
                                text = "CVSS ${finding.cvssScore}",
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp,
                                color = CyberCyan
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Text(
                        text = if (isEnglish) finding.title else finding.titleAr,
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp,
                        color = MaterialTheme.colorScheme.onSurface
                    )

                    Spacer(modifier = Modifier.height(4.dp))

                    Text(
                        text = "${finding.cweId} • ${finding.owaspCategory}",
                        fontFamily = FontFamily.Monospace,
                        fontSize = 11.sp,
                        color = CyberCyan
                    )
                }
            }
        }

        // Architectural Security Diagram
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("finding_diagram_card"),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(
                        text = if (isEnglish) "Architectural Security Flow Diagram" else "المخطط الهيكلي التفاعلي للثغرة وتدفق البيانات",
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    SecurityDiagramViewer(
                        diagramType = resolvedDiagram,
                        isEnglish = isEnglish
                    )
                }
            }
        }

        // Observed Evidence
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(
                        text = if (isEnglish) "Observed Real Evidence" else "الدليل الفني المرصود",
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(6.dp))
                            .background(Color(0xFF070E17))
                            .padding(12.dp)
                    ) {
                        Text(
                            text = finding.evidence,
                            fontFamily = FontFamily.Monospace,
                            fontSize = 11.sp,
                            color = CyberCyan
                        )
                    }
                }
            }
        }

        // Remediation Code Snippets with Technology Selector
        item {
            val techList = listOf("Nginx", "Apache", "Express", "PHP", "DNS")
            val tailoredSnippet = getTailoredCodeSnippet(finding, selectedTech)

            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(imageVector = Icons.Default.Build, contentDescription = null, tint = CyberEmerald, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = if (isEnglish) "Ready-to-Apply Mitigation Snippet" else "شيفرة المعالجة الفورية المباشرة",
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp,
                                color = CyberEmerald
                            )
                        }

                        IconButton(
                            onClick = {
                                val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                cm.setPrimaryClip(ClipData.newPlainText("Fix Snippet", tailoredSnippet))
                                Toast.makeText(context, if (isEnglish) "Copied to clipboard" else "تم نسخ شيفرة المعالجة", Toast.LENGTH_SHORT).show()
                            },
                            modifier = Modifier.size(28.dp).testTag("copy_snippet_button")
                        ) {
                            Icon(imageVector = Icons.Default.ContentCopy, contentDescription = "Copy", tint = CyberCyan, modifier = Modifier.size(16.dp))
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Tech selector chips
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        techList.forEach { tech ->
                            FilterChip(
                                selected = selectedTech == tech,
                                onClick = { selectedTech = tech },
                                label = { Text(text = tech, fontSize = 11.sp) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = CyberCyan,
                                    selectedLabelColor = Color.Black
                                )
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(Color(0xFF040B13))
                            .border(1.dp, Color(0xFF1E3A5F), RoundedCornerShape(8.dp))
                            .padding(12.dp)
                    ) {
                        Text(
                            text = tailoredSnippet,
                            fontFamily = FontFamily.Monospace,
                            fontSize = 11.sp,
                            color = CyberEmerald,
                            lineHeight = 16.sp
                        )
                    }

                    if (finding.verificationCommand.isNotBlank()) {
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = if (isEnglish) "Verification Command (curl)" else "أمر التحقق السريع من التطبيق (curl):",
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(6.dp))
                                .background(Color(0xFF0A1929))
                                .padding(10.dp)
                        ) {
                            Text(
                                text = finding.verificationCommand,
                                fontFamily = FontFamily.Monospace,
                                fontSize = 10.sp,
                                color = Color(0xFFFFB74D)
                            )
                        }
                    }
                }
            }
        }

        // Step by Step Remediation
        item {
            val steps = if (isEnglish) finding.remediationStepsEn else finding.remediationStepsAr
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(
                        text = if (isEnglish) "Step-by-Step Remediation" else "خطوات الإصلاح المقترحة",
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    steps.forEachIndexed { index, step ->
                        Row(
                            modifier = Modifier.padding(vertical = 2.dp),
                            verticalAlignment = Alignment.Top
                        ) {
                            Text(text = "${index + 1}. ", fontWeight = FontWeight.Bold, color = CyberEmerald, fontSize = 12.sp)
                            Text(text = step, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface)
                        }
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}

private fun getTailoredCodeSnippet(finding: SecurityFinding, tech: String): String {
    return when (tech) {
        "Apache" -> when (finding.id) {
            "HSTS-MISSING" -> "Header always set Strict-Transport-Security \"max-age=31536000; includeSubDomains; preload\""
            "CSP-MISSING" -> "Header set Content-Security-Policy \"default-src 'self'; script-src 'self'; object-src 'none';\""
            "X-FRAME-OPTIONS-MISSING" -> "Header always append X-Frame-Options SAMEORIGIN"
            "X-CONTENT-TYPE-OPTIONS-MISSING" -> "Header set X-Content-Type-Options nosniff"
            "SERVER-BANNER-DISCLOSURE" -> "ServerTokens Prod\nServerSignature Off"
            else -> finding.configSnippet.ifBlank { "# Consult Apache documentation for ${finding.id}" }
        }
        "Express" -> when (finding.id) {
            "HSTS-MISSING", "CSP-MISSING", "X-FRAME-OPTIONS-MISSING", "X-CONTENT-TYPE-OPTIONS-MISSING" ->
                "// npm install helmet\nconst helmet = require('helmet');\napp.use(helmet());"
            "SERVER-BANNER-DISCLOSURE", "X-POWERED-BY-DISCLOSURE" ->
                "app.disable('x-powered-by');"
            else -> finding.configSnippet
        }
        "PHP" -> when (finding.id) {
            "HSTS-MISSING" -> "header(\"Strict-Transport-Security: max-age=31536000; includeSubDomains; preload\");"
            "CSP-MISSING" -> "header(\"Content-Security-Policy: default-src 'self'; script-src 'self';\");"
            "X-FRAME-OPTIONS-MISSING" -> "header(\"X-Frame-Options: SAMEORIGIN\");"
            "X-CONTENT-TYPE-OPTIONS-MISSING" -> "header(\"X-Content-Type-Options: nosniff\");"
            "X-POWERED-BY-DISCLOSURE" -> "; php.ini:\nexpose_php = Off"
            else -> finding.configSnippet
        }
        "DNS" -> when (finding.id) {
            "DNS-SPF-MISSING" -> "@ IN TXT \"v=spf1 include:_spf.example.com -all\""
            "DNS-DMARC-MISSING" -> "_dmarc IN TXT \"v=DMARC1; p=reject; rua=mailto:dmarc-reports@example.com\""
            else -> finding.configSnippet
        }
        else -> finding.configSnippet.ifBlank { "# Nginx configuration:\nadd_header ${finding.affectedComponent} \"[secure_value]\" always;" }
    }
}
