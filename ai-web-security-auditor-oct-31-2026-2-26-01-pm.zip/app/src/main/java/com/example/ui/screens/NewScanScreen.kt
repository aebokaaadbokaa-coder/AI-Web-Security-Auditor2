package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.TargetScope
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.CyberEmerald
import com.example.ui.viewmodel.AuditorViewModel

@Composable
fun NewScanScreen(
    viewModel: AuditorViewModel,
    modifier: Modifier = Modifier
) {
    val targetUrl by viewModel.targetUrl.collectAsState()
    val hasConsent by viewModel.hasConsent.collectAsState()
    val scope by viewModel.scope.collectAsState()
    val isDemoMode by viewModel.isDemoMode.collectAsState()
    val isEnglish by viewModel.isEnglish.collectAsState()

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Spacer(modifier = Modifier.height(8.dp))

            // Header Card
            Card(
                modifier = Modifier.fillMaxWidth().testTag("new_scan_header_card"),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .clip(RoundedCornerShape(10.dp))
                                .background(MaterialTheme.colorScheme.primaryContainer),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(imageVector = Icons.Default.Shield, contentDescription = null, tint = CyberCyan)
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = if (isEnglish) "New Security Audit Configuration" else "إعداد فحص أمني جديد",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = if (isEnglish) "Target Scope, Protocols & Authorization" else "تحديد نطاق الفحص والتحقق من التصريح الأمني",
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }
        }

        // Demo Mode Switch
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(
                    containerColor = if (isDemoMode) Color(0xFF2A1500) else MaterialTheme.colorScheme.surface
                ),
                border = androidx.compose.foundation.BorderStroke(1.dp, if (isDemoMode) Color(0xFFFF9800) else MaterialTheme.colorScheme.outline)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = if (isEnglish) "Safe Demo Sandbox (Offline Models)" else "وضع البيانات التجريبية (Demo Mode)",
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp,
                                color = if (isDemoMode) Color(0xFFFFB74D) else MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = if (isEnglish) "Run simulated audits on sample e-commerce or bank targets" else "فحص محاكاة آمن لنماذج واقعية دون اتصال خارجي",
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Switch(
                            checked = isDemoMode,
                            onCheckedChange = { viewModel.setDemoMode(it) },
                            colors = SwitchDefaults.colors(checkedThumbColor = Color(0xFFFF9800))
                        )
                    }

                    if (isDemoMode) {
                        Spacer(modifier = Modifier.height(10.dp))
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(
                                onClick = { viewModel.runEcommerceDemo() },
                                modifier = Modifier.weight(1f),
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFE65100)),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Text(text = if (isEnglish) "E-Commerce (Risk C)" else "متجر إلكتروني (درجة C)", fontSize = 11.sp, color = Color.White)
                            }
                            Button(
                                onClick = { viewModel.runBankingDemo() },
                                modifier = Modifier.weight(1f),
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1B5E20)),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Text(text = if (isEnglish) "Bank Portal (Grade A+)" else "بوابة بنكية (درجة A+)", fontSize = 11.sp, color = Color.White)
                            }
                        }
                    }
                }
            }
        }

        // Live URL Input Card
        if (!isDemoMode) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = if (isEnglish) "Target Website URL" else "عنوان رابط الموقع المستهدف:",
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Spacer(modifier = Modifier.height(6.dp))

                        OutlinedTextField(
                            value = targetUrl,
                            onValueChange = { viewModel.setTargetUrl(it) },
                            modifier = Modifier.fillMaxWidth().testTag("new_scan_url_input"),
                            placeholder = { Text("https://example.com") },
                            leadingIcon = { Icon(imageVector = Icons.Default.Language, contentDescription = null, tint = CyberCyan) },
                            singleLine = true,
                            shape = RoundedCornerShape(8.dp),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = CyberCyan,
                                unfocusedBorderColor = MaterialTheme.colorScheme.outline
                            )
                        )

                        Spacer(modifier = Modifier.height(14.dp))

                        // Target Scope Selector
                        Text(
                            text = if (isEnglish) "Authorized Scope Policy:" else "سياسة نطاق الفحص المصرح به:",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Medium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            TargetScope.values().forEach { itemScope ->
                                val selected = scope == itemScope
                                Box(
                                    modifier = Modifier
                                        .weight(1f)
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(if (selected) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant)
                                        .border(1.dp, if (selected) CyberCyan else MaterialTheme.colorScheme.outline, RoundedCornerShape(8.dp))
                                        .clickable { viewModel.setScope(itemScope) }
                                        .padding(vertical = 10.dp, horizontal = 8.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = if (isEnglish) itemScope.labelEn else itemScope.labelAr,
                                        fontSize = 11.sp,
                                        fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal,
                                        color = if (selected) CyberCyan else MaterialTheme.colorScheme.onSurface,
                                        textAlign = TextAlign.Center
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        // Consent Checkbox
                        Row(
                            verticalAlignment = Alignment.Top,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                                .clickable { viewModel.setConsent(!hasConsent) }
                                .padding(8.dp)
                        ) {
                            Checkbox(
                                checked = hasConsent,
                                onCheckedChange = { viewModel.setConsent(it) },
                                colors = CheckboxDefaults.colors(checkedColor = CyberEmerald)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = if (isEnglish)
                                    "I explicitly certify that I own this domain or have documented legal authorization to run non-destructive defensive checks."
                                else
                                    "أقر صراحة بأنني أملك هذا النطاق أو أحوز تفويضاً كتابياً قانونياً بفحصه فحصاً دفاعياً غير تخريبي.",
                                fontSize = 11.sp,
                                lineHeight = 16.sp,
                                color = if (hasConsent) CyberEmerald else MaterialTheme.colorScheme.onSurface
                            )
                        }
                    }
                }
            }
        }

        // Launch Button
        item {
            Button(
                onClick = { viewModel.startScan() },
                modifier = Modifier.fillMaxWidth().height(52.dp).testTag("start_audit_button"),
                shape = RoundedCornerShape(10.dp),
                colors = ButtonDefaults.buttonColors(containerColor = CyberCyan),
                enabled = isDemoMode || hasConsent
            ) {
                Icon(imageVector = Icons.Default.PlayArrow, contentDescription = null, tint = Color.Black)
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = if (isDemoMode) {
                        if (isEnglish) "Run Demo Simulation" else "بدء الفحص التجريبي"
                    } else {
                        if (isEnglish) "Start Defensive Security Audit" else "إطلاق الفحص الأمني الدفاعي"
                    },
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp,
                    color = Color.Black
                )
            }
            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}
