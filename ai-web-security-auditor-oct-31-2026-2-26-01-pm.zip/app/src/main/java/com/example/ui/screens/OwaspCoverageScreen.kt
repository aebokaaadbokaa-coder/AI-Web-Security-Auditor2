package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Assessment
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.OwaspTop10Coverage
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.CyberEmerald

@Composable
fun OwaspCoverageScreen(isEnglish: Boolean, modifier: Modifier = Modifier) {
    val coverageList = listOf(
        OwaspTop10Coverage(
            code = "A01:2021",
            titleEn = "Broken Access Control",
            titleAr = "خلل في التحكم بالوصول والصلاحيات",
            supportedChecks = listOf("CORS Wildcard & Credentials Misalignment", "SameSite Cookie Directives", "Path Traversal Static Indicators"),
            executedChecksCount = 3,
            skippedChecksCount = 2,
            scopeLimitationsAr = "يغطي الفحص السلبي والساكن فقط. لا يشمل محاولات تجاوز تسجيل الدخول النشط أو التلاعب بالأدوار."
        ),
        OwaspTop10Coverage(
            code = "A02:2021",
            titleEn = "Cryptographic Failures",
            titleAr = "إخفاقات وفشل التشفير والشهادات الرقمية",
            supportedChecks = listOf("Cleartext HTTP Detection", "Deprecated TLS 1.0/1.1 Protocols", "Certificate Expiry & Issuer", "Weak Hash (MD5/SHA1) Static Scan"),
            executedChecksCount = 4,
            skippedChecksCount = 0,
            scopeLimitationsAr = "تغطية كاملة للفحص الدفاعي لبروتوكولات TLS وفحص الكود لخوارزميات التشفير المكسورة."
        ),
        OwaspTop10Coverage(
            code = "A03:2021",
            titleEn = "Injection",
            titleAr = "ثغرات الحقن (SQL, XSS, Command, Eval)",
            supportedChecks = listOf("CSP Anti-XSS Whitelist Review", "SQL Concatenation Static Scan", "Dangerous eval() & OS Exec Static Scan"),
            executedChecksCount = 3,
            skippedChecksCount = 3,
            scopeLimitationsAr = "يقتصر على مراجعة سياسة CSP وفحص الكود الثابت. لا يتم إرسال حمولات حقن هجومية على المواقع العامة."
        ),
        OwaspTop10Coverage(
            code = "A04:2021",
            titleEn = "Insecure Design",
            titleAr = "التصميم الأمني غير الآمن وغياب الضوابط",
            supportedChecks = listOf("Strict Scope Enforcement", "Rate Limit Headers Presence", "Open Redirect Static Check"),
            executedChecksCount = 2,
            skippedChecksCount = 2,
            scopeLimitationsAr = "يتطلب نمذجة التهديدات المعمارية الشاملة ومراجعة منطق الأعمال الداخلي."
        ),
        OwaspTop10Coverage(
            code = "A05:2021",
            titleEn = "Security Misconfiguration",
            titleAr = "أخطاء التكوين والإعدادات الأمنية (الترويسات والخوادم)",
            supportedChecks = listOf("HSTS (max-age, includeSubDomains)", "X-Frame-Options (Clickjacking)", "X-Content-Type-Options (nosniff)", "Referrer-Policy & Permissions-Policy", "Server & X-Powered-By Banner Disclosure"),
            executedChecksCount = 6,
            skippedChecksCount = 0,
            scopeLimitationsAr = "تغطية دفاعية عميقة بنسبة 100% لإعدادات الترويسات وترميزات خوادم الويب."
        ),
        OwaspTop10Coverage(
            code = "A06:2021",
            titleEn = "Vulnerable and Outdated Components",
            titleAr = "المكونات البرمجية القديمة والضعيفة (CVEs)",
            supportedChecks = listOf("Server Banner CVE Mapping", "Technology Fingerprint Matching", "Package Lock Static Indicators"),
            executedChecksCount = 2,
            skippedChecksCount = 1,
            scopeLimitationsAr = "يحدد الإصدارات المكشوفة صراحة. التحقق الدقيق من الحزم يعتمد على رفع ملفات dependencies كاملة."
        ),
        OwaspTop10Coverage(
            code = "A07:2021",
            titleEn = "Identification and Authentication Failures",
            titleAr = "إخفاقات تحديد الهوية والمصادقة (الجلسات والكوكيز)",
            supportedChecks = listOf("Cookie 'Secure' Attribute", "Cookie 'HttpOnly' Attribute", "Hardcoded Credentials in Code", "JWT Insecure 'none' Algorithm"),
            executedChecksCount = 4,
            skippedChecksCount = 1,
            scopeLimitationsAr = "يفحص إعدادات ملفات تعريف الارتباط والكود. لا يختبر تخمين كلمات المرور أو حماية الـ Brute Force."
        ),
        OwaspTop10Coverage(
            code = "A08:2021",
            titleEn = "Software and Data Integrity Failures",
            titleAr = "فشل سلامة البرمجيات والبيانات (SRI والبريد)",
            supportedChecks = listOf("SPF / DMARC Email Spoofing Records", "Subresource Integrity (SRI) Check", "Unsafe Deserialization Indicators"),
            executedChecksCount = 2,
            skippedChecksCount = 1,
            scopeLimitationsAr = "يغطي سجلات حماية النطاق وفحص الكود الثابت."
        ),
        OwaspTop10Coverage(
            code = "A09:2021",
            titleEn = "Security Logging and Monitoring Failures",
            titleAr = "إخفاقات تسجيل الأحداث والمراقبة الأمنية",
            supportedChecks = listOf("Coverage Ledger Audit Trail", "Exception Stack Trace Leakage Detection", "DMARC rua Telemetry"),
            executedChecksCount = 3,
            skippedChecksCount = 0,
            scopeLimitationsAr = "يراقب سجلات الفحص وتسريب مخرجات الأخطاء للعملاء."
        ),
        OwaspTop10Coverage(
            code = "A10:2021",
            titleEn = "Server-Side Request Forgery (SSRF)",
            titleAr = "تزوير الطلبات من جانب الخادم (SSRF)",
            supportedChecks = listOf("SSRF Guard Loopback Blocking (127.0.0.1)", "SSRF Guard Private IP Subnet Blocking (RFC1918)", "Cloud Metadata 169.254.x.x Protection", "Redirect Scope Validation", "Static SSRF Fetch Review"),
            executedChecksCount = 5,
            skippedChecksCount = 0,
            scopeLimitationsAr = "تغطية صارمة لحماية تطبيق الفحص نفسه ولرصد أنماط SSRF في الكود المصدري."
        )
    )

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Spacer(modifier = Modifier.height(8.dp))

            // Header Card
            Card(
                modifier = Modifier.fillMaxWidth().testTag("owasp_coverage_header_card"),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .clip(RoundedCornerShape(10.dp))
                                .background(MaterialTheme.colorScheme.primaryContainer),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(imageVector = Icons.Default.Assessment, contentDescription = null, tint = CyberCyan)
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = if (isEnglish) "OWASP Top 10 Coverage Matrix" else "مصفوفة تغطية معايير OWASP Top 10",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = if (isEnglish) "Honest breakdown of supported vs skipped checks" else "بيان شفاف للفحوصات المنفذة والمتخطاة وحدود الفحص الدفاعي",
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }
        }

        items(coverageList, key = { it.code }) { item ->
            Card(
                modifier = Modifier.fillMaxWidth().testTag("owasp_item_${item.code}"),
                shape = RoundedCornerShape(10.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "${item.code}: ${if (isEnglish) item.titleEn else item.titleAr}",
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            color = CyberCyan
                        )
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(4.dp))
                                .background(Color(0xFF042111))
                                .border(1.dp, CyberEmerald, RoundedCornerShape(4.dp))
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = "${item.executedChecksCount} Active",
                                fontSize = 10.sp,
                                color = CyberEmerald,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Text(text = if (isEnglish) "Supported Defensive Checks:" else "الفحوصات الدفاعية المدعومة:", fontSize = 11.sp, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    item.supportedChecks.forEach { check ->
                        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(vertical = 1.dp)) {
                            Icon(imageVector = Icons.Default.CheckCircle, contentDescription = null, tint = CyberEmerald, modifier = Modifier.size(12.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(text = check, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface)
                        }
                    }

                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "⚠️ حدود التغطية: ${item.scopeLimitationsAr}",
                        fontSize = 11.sp,
                        color = Color(0xFFFFB300)
                    )
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}
