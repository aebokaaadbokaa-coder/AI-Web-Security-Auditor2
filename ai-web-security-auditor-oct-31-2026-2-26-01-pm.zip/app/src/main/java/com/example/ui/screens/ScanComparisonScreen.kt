package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.CompareArrows
import androidx.compose.material.icons.filled.TrendingDown
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.AuditSummary
import com.example.model.Severity
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.CyberCrimson
import com.example.ui.theme.CyberEmerald
import com.example.ui.theme.SeverityCritical
import com.example.ui.theme.SeverityHigh
import com.example.ui.theme.SeverityMedium
import com.example.ui.viewmodel.AppScreen
import com.example.ui.viewmodel.AuditorViewModel

@Composable
fun ScanComparisonScreen(
    viewModel: AuditorViewModel,
    modifier: Modifier = Modifier
) {
    val first by viewModel.compareFirst.collectAsState()
    val second by viewModel.compareSecond.collectAsState()
    val isEnglish by viewModel.isEnglish.collectAsState()

    if (first == null || second == null) {
        Box(
            modifier = modifier.fillMaxSize(),
            contentAlignment = Alignment.Center
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.padding(24.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.CompareArrows,
                    contentDescription = null,
                    tint = CyberCyan,
                    modifier = Modifier.size(56.dp)
                )
                Spacer(modifier = Modifier.height(16.dp))
                Text(
                    text = if (isEnglish) "Select two scans from Scan History to perform differential comparison."
                    else "يرجى تحديد فحصين من سجل الفحوصات للمقارنة التحليلية بينهما.",
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    fontSize = 14.sp,
                    modifier = Modifier.testTag("empty_comparison_text")
                )
                Spacer(modifier = Modifier.height(16.dp))
                Button(
                    onClick = { viewModel.navigateTo(AppScreen.SCAN_HISTORY) },
                    colors = ButtonDefaults.buttonColors(containerColor = CyberCyan),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.testTag("return_to_history_button")
                ) {
                    Text(
                        text = if (isEnglish) "Go to Scan History" else "الانتقال إلى سجل الفحوصات",
                        color = Color.Black,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
        return
    }

    val scanA = first!!
    val scanB = second!!

    val scoreDelta = scanB.score - scanA.score
    val scoreImproved = scoreDelta > 0

    // Compare findings
    val scanAIds = scanA.findings.map { it.id }.toSet()
    val scanBIds = scanB.findings.map { it.id }.toSet()

    val fixedFindings = scanA.findings.filter { it.id !in scanBIds }
    val newFindings = scanB.findings.filter { it.id !in scanAIds }
    val persistentFindings = scanB.findings.filter { it.id in scanAIds }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Spacer(modifier = Modifier.height(8.dp))

            // Navigation Back Row
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                IconButton(
                    onClick = { viewModel.navigateTo(AppScreen.SCAN_HISTORY) },
                    modifier = Modifier.testTag("back_from_comparison_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.ArrowBack,
                        contentDescription = "Back",
                        tint = CyberCyan
                    )
                }
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = if (isEnglish) "Scan Differential Comparison" else "المقارنة التفاضلية بين الفحوصات",
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp,
                    color = MaterialTheme.colorScheme.onSurface
                )
            }
        }

        // Host Comparison Card
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("comparison_summary_card"),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = if (isEnglish) "Baseline (Scan A)" else "الفحص الأساسي (أ)",
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Text(
                                text = scanA.scannedHost,
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = "Grade ${scanA.overallGrade} • Score ${scanA.score}/100",
                                fontSize = 11.sp,
                                color = CyberCyan
                            )
                        }

                        Icon(
                            imageVector = Icons.Default.CompareArrows,
                            contentDescription = "Diff",
                            tint = CyberCyan,
                            modifier = Modifier
                                .padding(horizontal = 8.dp)
                                .size(28.dp)
                        )

                        Column(modifier = Modifier.weight(1f), horizontalAlignment = Alignment.End) {
                            Text(
                                text = if (isEnglish) "Target (Scan B)" else "الفحص المقارن (ب)",
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Text(
                                text = scanB.scannedHost,
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = "Grade ${scanB.overallGrade} • Score ${scanB.score}/100",
                                fontSize = 11.sp,
                                color = CyberEmerald
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Score Delta Indicator
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(
                                if (scoreDelta >= 0) Color(0xFF003822) else Color(0xFF3B0C11)
                            )
                            .padding(12.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.Center,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Icon(
                                imageVector = if (scoreDelta >= 0) Icons.Default.TrendingUp else Icons.Default.TrendingDown,
                                contentDescription = null,
                                tint = if (scoreDelta >= 0) CyberEmerald else CyberCrimson,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = if (isEnglish) {
                                    if (scoreDelta >= 0) "Security Posture Improved by +$scoreDelta pts" else "Security Posture Degraded by $scoreDelta pts"
                                } else {
                                    if (scoreDelta >= 0) "تحسن المستوى الأمني بمقدار +$scoreDelta نقطة" else "تراجع المستوى الأمني بمقدار $scoreDelta نقطة"
                                },
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp,
                                color = if (scoreDelta >= 0) CyberEmerald else CyberCrimson
                            )
                        }
                    }
                }
            }
        }

        // Metrics Grid (Critical, High, Medium, TLS)
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(
                        text = if (isEnglish) "Vulnerability Delta Summary" else "ملخص التغير في الثغرات الأمنية",
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        DeltaMetricItem("Critical", scanA.criticalCount, scanB.criticalCount, SeverityCritical, isEnglish)
                        DeltaMetricItem("High", scanA.highCount, scanB.highCount, SeverityHigh, isEnglish)
                        DeltaMetricItem("Medium", scanA.mediumCount, scanB.mediumCount, SeverityMedium, isEnglish)
                        DeltaMetricItem("Total", scanA.findings.size, scanB.findings.size, CyberCyan, isEnglish)
                    }
                }
            }
        }

        // Section: Resolved / Fixed Vulnerabilities
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(imageVector = Icons.Default.CheckCircle, contentDescription = null, tint = CyberEmerald, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = if (isEnglish) "Resolved Vulnerabilities (${fixedFindings.size})" else "الثغرات التي تم علاجها (${fixedFindings.size})",
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp,
                    color = CyberEmerald
                )
            }
        }

        if (fixedFindings.isEmpty()) {
            item {
                Text(
                    text = if (isEnglish) "No vulnerabilities were resolved between these scans." else "لم يتم حل ثغرات مسجلة بين هذين الفحصين.",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(horizontal = 8.dp)
                )
            }
        } else {
            items(fixedFindings, key = { "fixed_${it.id}" }) { finding ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(8.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF002919)),
                    border = androidx.compose.foundation.BorderStroke(1.dp, CyberEmerald)
                ) {
                    Row(modifier = Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(imageVector = Icons.Default.CheckCircle, contentDescription = null, tint = CyberEmerald, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Column {
                            Text(text = if (isEnglish) finding.title else finding.titleAr, fontWeight = FontWeight.Bold, fontSize = 12.sp, color = Color.White)
                            Text(text = "${finding.cweId} • ${finding.affectedComponent}", fontFamily = FontFamily.Monospace, fontSize = 10.sp, color = CyberEmerald)
                        }
                    }
                }
            }
        }

        // Section: New Regressions / Introduced Vulnerabilities
        item {
            Spacer(modifier = Modifier.height(6.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(imageVector = Icons.Default.Warning, contentDescription = null, tint = CyberCrimson, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = if (isEnglish) "Newly Introduced Vulnerabilities (${newFindings.size})" else "الثغرات المكتشفة حديثاً (${newFindings.size})",
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp,
                    color = CyberCrimson
                )
            }
        }

        if (newFindings.isEmpty()) {
            item {
                Text(
                    text = if (isEnglish) "No new security regressions introduced." else "لم تظهر أي ثغرات أو تراجعات أمنية جديدة.",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(horizontal = 8.dp)
                )
            }
        } else {
            items(newFindings, key = { "new_${it.id}" }) { finding ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(8.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF330910)),
                    border = androidx.compose.foundation.BorderStroke(1.dp, CyberCrimson)
                ) {
                    Row(modifier = Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(imageVector = Icons.Default.Warning, contentDescription = null, tint = CyberCrimson, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Column {
                            Text(text = if (isEnglish) finding.title else finding.titleAr, fontWeight = FontWeight.Bold, fontSize = 12.sp, color = Color.White)
                            Text(text = "${finding.cweId} • ${finding.affectedComponent}", fontFamily = FontFamily.Monospace, fontSize = 10.sp, color = CyberCrimson)
                        }
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}

@Composable
private fun DeltaMetricItem(
    label: String,
    countA: Int,
    countB: Int,
    color: Color,
    isEnglish: Boolean
) {
    val delta = countB - countA
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(text = label, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(text = "$countA → $countB", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = color)
        Text(
            text = if (delta > 0) "+$delta" else "$delta",
            fontSize = 10.sp,
            fontWeight = FontWeight.SemiBold,
            color = if (delta <= 0) CyberEmerald else CyberCrimson
        )
    }
}
