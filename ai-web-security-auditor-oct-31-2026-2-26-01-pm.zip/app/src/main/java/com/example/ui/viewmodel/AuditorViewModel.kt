package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.ai.PostFixCheckItem
import com.example.ai.ResponsibleDisclosureDraft
import com.example.ai.SecurityAiAdvisor
import com.example.data.AuditDatabase
import com.example.data.AuditRecordEntity
import com.example.data.AuditRepository
import com.example.demo.DemoScenarios
import com.example.model.AuditSummary
import com.example.model.ScanState
import com.example.model.SecurityFinding
import com.example.model.TargetScope
import com.example.security.SafeAuditorClient
import com.example.security.SsrfGuard
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

enum class AppScreen(val labelEn: String, val labelAr: String) {
    SPLASH("Splash", "البداية"),
    DASHBOARD("Dashboard", "الرئيسية"),
    NEW_SCAN("New Scan", "فحص جديد"),
    SCAN_PROGRESS("Scan Progress", "مؤشر التقدم"),
    FINDINGS("Findings", "نتائج الفحص"),
    FINDING_DETAILS("Finding Details", "تفاصيل النتيجة"),
    VIEW_FIX("View Fix", "دليل الإصلاح"),
    ENGINE_HEALTH("Engine Health", "صحة المحركات"),
    SCAN_HISTORY("Scan History", "السجل"),
    SCAN_COMPARISON("Comparison", "المقارنة"),
    STATIC_CODE("Static Code Audit", "فحص الكود"),
    SELF_TEST_LAB("Self-Test Lab", "مختبر الفحص"),
    OWASP_COVERAGE("OWASP Coverage", "تغطية OWASP"),
    REPORTS("Reports & Disclosure", "التقارير"),
    AI_ASSISTANT("AI Assistant", "المستشار الذكي"),
    SETTINGS("Settings", "الإعدادات"),
    ABOUT("About & Architecture", "حول التطبيق")
}

// Retain AppTab for bottom navigation integration
enum class AppTab(val screen: AppScreen, val labelEn: String, val labelAr: String) {
    DASHBOARD(AppScreen.DASHBOARD, "Auditor", "الرئيسية"),
    NEW_SCAN(AppScreen.NEW_SCAN, "New Scan", "فحص جديد"),
    RESULTS(AppScreen.FINDINGS, "Findings", "النتائج"),
    AI_ASSISTANT(AppScreen.AI_ASSISTANT, "AI Assistant", "المستشار"),
    TOOLS(AppScreen.ENGINE_HEALTH, "Security Hub", "الأدوات")
}

class AuditorViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: AuditRepository
    private val auditorClient = SafeAuditorClient()

    private val _currentScreen = MutableStateFlow(AppScreen.SPLASH)
    val currentScreen: StateFlow<AppScreen> = _currentScreen.asStateFlow()

    private val _targetUrl = MutableStateFlow("https://example.com")
    val targetUrl: StateFlow<String> = _targetUrl.asStateFlow()

    private val _hasConsent = MutableStateFlow(false)
    val hasConsent: StateFlow<Boolean> = _hasConsent.asStateFlow()

    private val _scope = MutableStateFlow(TargetScope.STRICT_HOST)
    val scope: StateFlow<TargetScope> = _scope.asStateFlow()

    private val _isDemoMode = MutableStateFlow(false)
    val isDemoMode: StateFlow<Boolean> = _isDemoMode.asStateFlow()

    private val _scanState = MutableStateFlow<ScanState>(ScanState.Idle)
    val scanState: StateFlow<ScanState> = _scanState.asStateFlow()

    private val _scanLogs = MutableStateFlow<List<String>>(emptyList())
    val scanLogs: StateFlow<List<String>> = _scanLogs.asStateFlow()

    private val _currentSummary = MutableStateFlow<AuditSummary?>(null)
    val currentSummary: StateFlow<AuditSummary?> = _currentSummary.asStateFlow()

    private val _historyList = MutableStateFlow<List<AuditRecordEntity>>(emptyList())
    val historyList: StateFlow<List<AuditRecordEntity>> = _historyList.asStateFlow()

    private val _selectedFinding = MutableStateFlow<SecurityFinding?>(null)
    val selectedFinding: StateFlow<SecurityFinding?> = _selectedFinding.asStateFlow()

    private val _checkItems = MutableStateFlow<List<PostFixCheckItem>>(emptyList())
    val checkItems: StateFlow<List<PostFixCheckItem>> = _checkItems.asStateFlow()

    private val _disclosureDraft = MutableStateFlow<ResponsibleDisclosureDraft?>(null)
    val disclosureDraft: StateFlow<ResponsibleDisclosureDraft?> = _disclosureDraft.asStateFlow()

    private val _isEnglish = MutableStateFlow(false)
    val isEnglish: StateFlow<Boolean> = _isEnglish.asStateFlow()

    // 3GB RAM Mode & Performance settings
    private val _isMemorySaverMode = MutableStateFlow(true)
    val isMemorySaverMode: StateFlow<Boolean> = _isMemorySaverMode.asStateFlow()

    private val _requestTimeoutSeconds = MutableStateFlow(6)
    val requestTimeoutSeconds: StateFlow<Int> = _requestTimeoutSeconds.asStateFlow()

    // Comparison Mode
    private val _compareFirst = MutableStateFlow<AuditSummary?>(null)
    val compareFirst: StateFlow<AuditSummary?> = _compareFirst.asStateFlow()

    private val _compareSecond = MutableStateFlow<AuditSummary?>(null)
    val compareSecond: StateFlow<AuditSummary?> = _compareSecond.asStateFlow()

    private var scanJob: Job? = null

    init {
        val database = AuditDatabase.getDatabase(application)
        repository = AuditRepository(database.auditDao())
        loadHistory()
    }

    private fun loadHistory() {
        viewModelScope.launch {
            repository.getAuditHistory().collect { list ->
                _historyList.value = list
            }
        }
    }

    fun navigateTo(screen: AppScreen) {
        _currentScreen.value = screen
    }

    fun dismissSplash() {
        _currentScreen.value = AppScreen.DASHBOARD
    }

    fun setTargetUrl(url: String) {
        _targetUrl.value = url
    }

    fun setConsent(consent: Boolean) {
        _hasConsent.value = consent
    }

    fun setScope(scope: TargetScope) {
        _scope.value = scope
    }

    fun setDemoMode(isDemo: Boolean) {
        _isDemoMode.value = isDemo
    }

    fun toggleLanguage() {
        _isEnglish.value = !_isEnglish.value
    }

    fun toggleMemorySaver() {
        _isMemorySaverMode.value = !_isMemorySaverMode.value
    }

    fun selectFinding(finding: SecurityFinding?) {
        _selectedFinding.value = finding
    }

    fun startScan() {
        if (!_hasConsent.value && !_isDemoMode.value) {
            _scanState.value = ScanState.Error(
                messageAr = "يجب تأكيد إقرار التصريح بفحص الموقع قبل البدء لحماية النطاقات والامتثال القانوني.",
                messageEn = "You must confirm authorization to audit this target before starting."
            )
            return
        }

        if (_isDemoMode.value) {
            runEcommerceDemo()
            return
        }

        val rawUrl = _targetUrl.value.trim()
        val ssrfPreCheck = SsrfGuard.validateTargetUrl(rawUrl)
        if (ssrfPreCheck is SsrfGuard.ValidationResult.Blocked) {
            _scanState.value = ScanState.Error(
                messageAr = ssrfPreCheck.reasonAr,
                messageEn = ssrfPreCheck.reasonEn,
                isSsrfBlocked = true
            )
            return
        }

        scanJob?.cancel()
        _scanLogs.value = listOf("Initializing Native Defensive Audit Engine...", "Validating Target URI & Scope...")
        _currentScreen.value = AppScreen.SCAN_PROGRESS

        scanJob = viewModelScope.launch {
            _scanState.value = ScanState.Scanning("Starting Engine...", "بدء تشغيل محرك الفحص الأمني...", 0.05f)

            try {
                val summary = auditorClient.auditTarget(rawUrl, _scope.value) { stepEn, stepAr, progress ->
                    _scanState.value = ScanState.Scanning(stepEn, stepAr, progress)
                    _scanLogs.value = _scanLogs.value + "[$stepEn] -> Progress: ${(progress * 100).toInt()}%"
                }

                _currentSummary.value = summary
                _scanState.value = ScanState.Success(summary)

                // Save to Room DB
                repository.saveAudit(summary)

                // Prepare AI Checklist and Disclosure
                _checkItems.value = SecurityAiAdvisor.generatePostFixChecklist(summary.findings)
                _disclosureDraft.value = SecurityAiAdvisor.generateResponsibleDisclosure(summary)

                // Switch to Results Screen
                _currentScreen.value = AppScreen.FINDINGS

            } catch (e: SecurityException) {
                _scanState.value = ScanState.Error(
                    messageAr = e.localizedMessage ?: "تم حظر الفحص أمنياً لمنع هجمات SSRF",
                    messageEn = e.localizedMessage ?: "Audit blocked by SSRF defense",
                    isSsrfBlocked = true
                )
                _scanLogs.value = _scanLogs.value + "CRITICAL BLOCKED: ${e.localizedMessage}"
            } catch (e: Exception) {
                _scanState.value = ScanState.Error(
                    messageAr = "تعذر إكمال الفحص الأمني: ${e.localizedMessage ?: "خطأ في الشبكة أو الخادم"}",
                    messageEn = "Audit failed: ${e.localizedMessage ?: "Network or server failure"}"
                )
                _scanLogs.value = _scanLogs.value + "FAILED: ${e.localizedMessage}"
            }
        }
    }

    fun stopScan() {
        scanJob?.cancel()
        scanJob = null
        _scanState.value = ScanState.Idle
        _scanLogs.value = _scanLogs.value + "Scan stopped by user action."
    }

    fun runEcommerceDemo() {
        viewModelScope.launch {
            _currentScreen.value = AppScreen.SCAN_PROGRESS
            _scanLogs.value = listOf("Initializing Simulated Demo Sandbox...", "Loading E-Commerce Security Fixtures...")
            _scanState.value = ScanState.Scanning("Simulating E-Commerce Audit...", "جاري محاكاة فحص متجر إلكتروني...", 0.5f)
            kotlinx.coroutines.delay(600)
            val demoSummary = DemoScenarios.getEcommerceDemo()
            _currentSummary.value = demoSummary
            _scanState.value = ScanState.Success(demoSummary)
            _checkItems.value = SecurityAiAdvisor.generatePostFixChecklist(demoSummary.findings)
            _disclosureDraft.value = SecurityAiAdvisor.generateResponsibleDisclosure(demoSummary)
            _currentScreen.value = AppScreen.FINDINGS
        }
    }

    fun runBankingDemo() {
        viewModelScope.launch {
            _currentScreen.value = AppScreen.SCAN_PROGRESS
            _scanLogs.value = listOf("Initializing Simulated Demo Sandbox...", "Loading Hardened Banking Gateway Fixtures...")
            _scanState.value = ScanState.Scanning("Simulating Banking Audit...", "جاري محاكاة فحص بوابة بنك مؤمنة...", 0.5f)
            kotlinx.coroutines.delay(600)
            val demoSummary = DemoScenarios.getHardenedBankingDemo()
            _currentSummary.value = demoSummary
            _scanState.value = ScanState.Success(demoSummary)
            _checkItems.value = SecurityAiAdvisor.generatePostFixChecklist(demoSummary.findings)
            _disclosureDraft.value = SecurityAiAdvisor.generateResponsibleDisclosure(demoSummary)
            _currentScreen.value = AppScreen.FINDINGS
        }
    }

    fun toggleCheckItem(id: String) {
        _checkItems.value = _checkItems.value.map {
            if (it.id == id) it.copy(isChecked = !it.isChecked) else it
        }
    }

    fun loadHistoricalScan(recordId: String) {
        viewModelScope.launch {
            val summary = repository.getAuditById(recordId)
            if (summary != null) {
                _currentSummary.value = summary
                _scanState.value = ScanState.Success(summary)
                _checkItems.value = SecurityAiAdvisor.generatePostFixChecklist(summary.findings)
                _disclosureDraft.value = SecurityAiAdvisor.generateResponsibleDisclosure(summary)
                _currentScreen.value = AppScreen.FINDINGS
            }
        }
    }

    fun selectForComparison(recordId: String, isFirst: Boolean) {
        viewModelScope.launch {
            val summary = repository.getAuditById(recordId)
            if (isFirst) {
                _compareFirst.value = summary
            } else {
                _compareSecond.value = summary
            }
            if (_compareFirst.value != null && _compareSecond.value != null) {
                _currentScreen.value = AppScreen.SCAN_COMPARISON
            }
        }
    }

    fun deleteHistoricalScan(recordId: String) {
        viewModelScope.launch {
            repository.deleteAudit(recordId)
        }
    }
}
