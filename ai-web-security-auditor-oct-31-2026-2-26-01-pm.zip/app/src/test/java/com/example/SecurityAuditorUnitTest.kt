package com.example

import com.example.ai.SecurityAiAdvisor
import com.example.data.AuditRepository
import com.example.demo.DemoScenarios
import com.example.model.AuditSummary
import com.example.model.Category
import com.example.model.Confidence
import com.example.model.SecurityFinding
import com.example.model.Severity
import com.example.reporting.ReportExporter
import com.example.security.SsrfGuard
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.net.InetAddress
class SecurityAuditorUnitTest {

    // 1. SSRF Guard: Loopback 127.0.0.1
    @Test
    fun `test ssrf guard blocks 127_0_0_1 loopback address`() {
        val loopback = InetAddress.getByName("127.0.0.1")
        val result = SsrfGuard.validateIpAddress(loopback)
        assertTrue("Expected 127.0.0.1 to be blocked", result is SsrfGuard.ValidationResult.Blocked)
    }

    // 2. SSRF Guard: RFC1918 Private Subnets (10.0.0.1, 172.16.0.1, 192.168.1.1)
    @Test
    fun `test ssrf guard blocks 10_0_0_1 private network`() {
        val classA = InetAddress.getByName("10.0.0.1")
        val result = SsrfGuard.validateIpAddress(classA)
        assertTrue("Expected 10.0.0.1 to be blocked", result is SsrfGuard.ValidationResult.Blocked)
    }

    @Test
    fun `test ssrf guard blocks 172_16_0_1 private network`() {
        val classB = InetAddress.getByName("172.16.0.1")
        val result = SsrfGuard.validateIpAddress(classB)
        assertTrue("Expected 172.16.0.1 to be blocked", result is SsrfGuard.ValidationResult.Blocked)
    }

    @Test
    fun `test ssrf guard blocks 192_168_1_1 private network`() {
        val classC = InetAddress.getByName("192.168.1.1")
        val result = SsrfGuard.validateIpAddress(classC)
        assertTrue("Expected 192.168.1.1 to be blocked", result is SsrfGuard.ValidationResult.Blocked)
    }

    // 3. SSRF Guard: Cloud Metadata 169.254.169.254
    @Test
    fun `test ssrf guard blocks 169_254_169_254 cloud metadata service`() {
        val metadataIp = InetAddress.getByName("169.254.169.254")
        val result = SsrfGuard.validateIpAddress(metadataIp)
        assertTrue("Expected 169.254.169.254 to be blocked", result is SsrfGuard.ValidationResult.Blocked)
    }

    // 4. SSRF Guard: IPv6 Loopback (::1)
    @Test
    fun `test ssrf guard blocks IPv6 loopback`() {
        val ipv6Loopback = InetAddress.getByName("::1")
        val result = SsrfGuard.validateIpAddress(ipv6Loopback)
        assertTrue("Expected IPv6 loopback ::1 to be blocked", result is SsrfGuard.ValidationResult.Blocked)
    }

    // 5. SSRF Guard: IPv6 Private & Link-Local (fe80::1)
    @Test
    fun `test ssrf guard blocks IPv6 link-local`() {
        val ipv6LinkLocal = InetAddress.getByName("fe80::1")
        val result = SsrfGuard.validateIpAddress(ipv6LinkLocal)
        assertTrue("Expected IPv6 link-local fe80::1 to be blocked", result is SsrfGuard.ValidationResult.Blocked)
    }

    // 6. SSRF Guard: IPv6 Unique Local Address (ULA) (fc00::/7 and fd00::/8)
    @Test
    fun `test ssrf guard blocks IPv6 unique local address ULA`() {
        val ipv6Ula1 = InetAddress.getByName("fc00::1")
        val ipv6Ula2 = InetAddress.getByName("fd12:3456:789a:1::1")

        assertTrue("Expected fc00::1 to be blocked", SsrfGuard.validateIpAddress(ipv6Ula1) is SsrfGuard.ValidationResult.Blocked)
        assertTrue("Expected fd12:... to be blocked", SsrfGuard.validateIpAddress(ipv6Ula2) is SsrfGuard.ValidationResult.Blocked)
    }

    // 7. SSRF Guard: IPv4-mapped IPv6 addresses (::ffff:127.0.0.1, ::ffff:10.0.0.1)
    @Test
    fun `test ssrf guard blocks IPv4-mapped IPv6 loopback and private addresses`() {
        val mappedLoopback = InetAddress.getByName("::ffff:127.0.0.1")
        val mappedPrivate = InetAddress.getByName("::ffff:10.0.0.1")
        val mappedMetadata = InetAddress.getByName("::ffff:169.254.169.254")

        assertTrue("Expected ::ffff:127.0.0.1 to be blocked", SsrfGuard.validateIpAddress(mappedLoopback) is SsrfGuard.ValidationResult.Blocked)
        assertTrue("Expected ::ffff:10.0.0.1 to be blocked", SsrfGuard.validateIpAddress(mappedPrivate) is SsrfGuard.ValidationResult.Blocked)
        assertTrue("Expected ::ffff:169.254.169.254 to be blocked", SsrfGuard.validateIpAddress(mappedMetadata) is SsrfGuard.ValidationResult.Blocked)
    }

    // 8. SSRF Guard: Alternative IP encodings & host strings (octal, hex, dword)
    @Test
    fun `test ssrf guard blocks alternative IP encodings and bypass patterns`() {
        val dwordCheck = SsrfGuard.validateTargetUrl("http://2130706433")
        assertTrue("Expected dword IP 2130706433 to be blocked", dwordCheck is SsrfGuard.ValidationResult.Blocked)

        val hexCheck = SsrfGuard.validateTargetUrl("http://0x7f000001")
        assertTrue("Expected hex IP 0x7f000001 to be blocked", hexCheck is SsrfGuard.ValidationResult.Blocked)

        val octalCheck = SsrfGuard.validateTargetUrl("http://0177.0.0.1")
        assertTrue("Expected octal IP 0177.0.0.1 to be blocked", octalCheck is SsrfGuard.ValidationResult.Blocked)
    }

    // 9. SSRF Guard: URL parsing edge cases
    @Test
    fun `test ssrf guard url parsing edge cases`() {
        // Empty URL
        assertTrue(SsrfGuard.validateTargetUrl("") is SsrfGuard.ValidationResult.Blocked)
        assertTrue(SsrfGuard.validateTargetUrl("   ") is SsrfGuard.ValidationResult.Blocked)

        // Unsupported scheme
        val ftpCheck = SsrfGuard.validateTargetUrl("ftp://ftp.example.com")
        assertTrue(ftpCheck is SsrfGuard.ValidationResult.Blocked)

        val fileCheck = SsrfGuard.validateTargetUrl("file:///etc/passwd")
        assertTrue(fileCheck is SsrfGuard.ValidationResult.Blocked)

        // Internal TLDs
        val localTldCheck = SsrfGuard.validateTargetUrl("http://internal-service.local")
        assertTrue(localTldCheck is SsrfGuard.ValidationResult.Blocked)

        val corpTldCheck = SsrfGuard.validateTargetUrl("http://intranet.corp")
        assertTrue(corpTldCheck is SsrfGuard.ValidationResult.Blocked)

        val metadataGcpCheck = SsrfGuard.validateTargetUrl("http://metadata.google.internal")
        assertTrue(metadataGcpCheck is SsrfGuard.ValidationResult.Blocked)
    }

    // 10. Redirect to blocked IP / host
    @Test
    fun `test ssrf guard redirect to blocked host or internal target is rejected`() {
        // Disallowed internal redirect destinations
        assertFalse(SsrfGuard.isRedirectAllowed("example.com", "http://127.0.0.1/admin", strictHostOnly = false))
        assertFalse(SsrfGuard.isRedirectAllowed("example.com", "http://localhost/setup", strictHostOnly = false))
        assertFalse(SsrfGuard.isRedirectAllowed("example.com", "http://169.254.169.254/latest/meta-data", strictHostOnly = false))
        assertFalse(SsrfGuard.isRedirectAllowed("example.com", "http://corp-server.internal", strictHostOnly = false))

        // Strict scope: subdomains disallowed
        assertFalse(SsrfGuard.isRedirectAllowed("example.com", "https://evil.com/login", strictHostOnly = true))
        assertFalse(SsrfGuard.isRedirectAllowed("example.com", "https://sub.example.com", strictHostOnly = true))
        assertTrue(SsrfGuard.isRedirectAllowed("example.com", "https://example.com/checkout", strictHostOnly = true))

        // Subdomain scope allowed:
        assertTrue(SsrfGuard.isRedirectAllowed("example.com", "https://auth.example.com", strictHostOnly = false))
        assertFalse(SsrfGuard.isRedirectAllowed("example.com", "https://attacker.org", strictHostOnly = false))
    }

    // 11. DNS Rebinding Protection Test:
    // When DNS resolution resolves to a private IP, it must be intercepted before network connection
    @Test
    fun `test dns resolution to private ip throws security exception in okhttp dns hook`() {
        val addresses = listOf(
            InetAddress.getByName("127.0.0.1"),
            InetAddress.getByName("10.0.0.1"),
            InetAddress.getByName("192.168.0.1")
        )

        for (addr in addresses) {
            val check = SsrfGuard.validateIpAddress(addr)
            assertTrue("DNS resolved IP ${addr.hostAddress} must be blocked by SSRF Guard", check is SsrfGuard.ValidationResult.Blocked)
        }
    }

    // 12. Static Code Reviewer Engine Test
    @Test
    fun `test static code reviewer detects hardcoded secrets and sql injection`() {
        val snippetWithAwsKey = """
            val awsAccessKey = "AKIAIOSFODNN7EXAMPLE"
            val query = "SELECT * FROM users WHERE id = '" + userId + "'"
        """.trimIndent()

        val findings = com.example.security.StaticCodeReviewer.reviewCode(snippetWithAwsKey, "test.kt")
        assertTrue("Static code reviewer should detect AWS secret", findings.any { it.id.contains("AWS-KEY") })
        assertTrue("Static code reviewer should detect SQL injection pattern", findings.any { it.id.contains("SQL") })
    }

    // 13. Self-Test Lab Engine Test
    @Test
    fun `test self test lab engine evaluates sample fixtures offline`() {
        val results = com.example.security.SelfTestLabEngine.runAllSelfTests()
        assertNotNull(results)
        assertTrue("Self-test lab should execute tests", results.isNotEmpty())
        assertTrue("All self-test offline fixture checks should pass", results.all { it.passed })
    }

    // 14. JSON Serialization & Deserialization Test
    @Test
    fun `test json serialization and deserialization of audit summary`() {
        val demo = DemoScenarios.getEcommerceDemo()
        val json = AuditRepository.serializeSummaryToJson(demo)

        assertNotNull(json)
        assertTrue(json.contains("demo-ecommerce-store.example.com"))

        val restored = AuditRepository.deserializeSummaryFromJson(json)
        assertNotNull(restored)
        assertEquals(demo.id, restored!!.id)
        assertEquals(demo.score, restored.score)
        assertEquals(demo.overallGrade, restored.overallGrade)
        assertEquals(demo.findings.size, restored.findings.size)
        assertEquals(demo.findings[0].id, restored.findings[0].id)
    }

    // 15. HTML Report Exporter Test
    @Test
    fun `test html report exporter contains critical security sections`() {
        val demo = DemoScenarios.getEcommerceDemo()
        val html = ReportExporter.generateHtmlReport(demo)

        assertNotNull(html)
        assertTrue(html.contains("<!DOCTYPE html>"))
        assertTrue(html.contains("AI Web Security Auditor"))
        assertTrue(html.contains("demo-ecommerce-store.example.com"))
        assertTrue(html.contains("DEMO DATA"))
        assertTrue(html.contains("Executive Summary"))
        assertTrue(html.contains("الدليل المرصود (Evidence)"))
    }

    // 16. AI Security Advisor Test
    @Test
    fun `test ai advisor generates post-fix checklist and responsible disclosure`() = runBlocking<Unit> {
        val demo = DemoScenarios.getEcommerceDemo()
        val checklist = SecurityAiAdvisor.generatePostFixChecklist(demo.findings)

        assertTrue(checklist.isNotEmpty())
        assertTrue(checklist.any { it.testCommand.contains("curl") })

        val disclosure = SecurityAiAdvisor.generateResponsibleDisclosure(demo)
        assertNotNull(disclosure)
        assertTrue(disclosure.subject.contains(demo.scannedHost))
        assertTrue(disclosure.bodyMarkdown.contains("Responsible Disclosure"))
    }

    // 17. Hardened vs Vulnerable Baseline Test
    @Test
    fun `test hardened bank demo has perfect A plus grade`() {
        val bankDemo = DemoScenarios.getHardenedBankingDemo()
        assertEquals("A+", bankDemo.overallGrade)
        assertEquals(100, bankDemo.score)
        assertEquals(0, bankDemo.criticalCount)
        assertEquals(0, bankDemo.highCount)
        assertTrue(bankDemo.isDemoScan)
    }
}
